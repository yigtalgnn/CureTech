module com.curetech {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires com.google.gson;
    requires MaterialFX;
    requires java.desktop;
    requires java.logging;
    requires java.sql;

    exports com.curetech;
    opens com.curetech to javafx.fxml, javafx.graphics;
}
