package com.curetech;

import io.github.palexdev.materialfx.controls.MFXButton;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.scene.paint.Color;

public class MainDashboard {
    private Stage stage;
    private User currentUser;
    private VBox contentArea;
    private HBox mainLayout;

    public MainDashboard(Stage stage, User user) {
        this.stage = stage;
        this.currentUser = user;
        initialize();
    }

    private void initialize() {
        mainLayout = new HBox();
        mainLayout.setStyle("-fx-background-color: #f8f9fa;");

        // Sol menü
        VBox leftMenu = createLeftMenu();
        HBox.setHgrow(leftMenu, Priority.NEVER);

        // İçerik alanı
        contentArea = new VBox();
        contentArea.setStyle("-fx-background-color: white;");
        contentArea.setPadding(new Insets(20));
        HBox.setHgrow(contentArea, Priority.ALWAYS);

        mainLayout.getChildren().addAll(leftMenu, contentArea);

        // Varsayılan olarak Satış ekranını göster
        showSalesManagement();
    }

    public void show() {
        Scene scene = new Scene(mainLayout, 1200, 800);
        stage.setTitle("CureTech - Ana Sayfa");
        stage.setScene(scene);
        stage.show();
    }

    private VBox createLeftMenu() {
        VBox menu = new VBox(10);
        menu.setPrefWidth(250);
        menu.setStyle("-fx-background-color: #1a1a1a;");
        menu.setPadding(new Insets(20));

        // Logo ve başlık
        VBox logoBox = new VBox(5);
        logoBox.setAlignment(Pos.CENTER);
        logoBox.setPadding(new Insets(0, 0, 30, 0));

        Label titleLabel = new Label("CureTech");
        titleLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 28));
        titleLabel.setTextFill(Color.WHITE);

        Label subtitleLabel = new Label("Eczane Yönetim Sistemi");
        subtitleLabel.setFont(Font.font("Roboto", FontWeight.NORMAL, 14));
        subtitleLabel.setTextFill(Color.web("#9e9e9e"));

        logoBox.getChildren().addAll(titleLabel, subtitleLabel);

        // Kullanıcı bilgisi
        Label userLabel = new Label(currentUser.getUsername());
        userLabel.setFont(Font.font("Segoe UI", FontWeight.MEDIUM, 14));
        userLabel.setTextFill(Color.web("#e0e0e0"));
        
        Label roleLabel = new Label(currentUser.getRole());
        roleLabel.setFont(Font.font("Segoe UI", FontWeight.NORMAL, 12));
        roleLabel.setTextFill(Color.web("#9E9E9E"));

        VBox userInfo = new VBox(5);
        userInfo.setAlignment(Pos.CENTER);
        userInfo.getChildren().addAll(userLabel, roleLabel);
        userInfo.setPadding(new Insets(0, 0, 20, 0));

        // Menü butonları
        MFXButton salesButton = createMenuButton("Satış", "💰", this::showSalesManagement);
        MFXButton medicationsButton = createMenuButton("İlaç Yönetimi", "💊", this::showMedicationManagement);
        MFXButton patientsButton = createMenuButton("Hasta Yönetimi", "👥", this::showPatientManagement);
        MFXButton prescriptionsButton = createMenuButton("Reçete Yönetimi", "📋", this::showPrescriptionManagement);
        MFXButton reportsButton = createMenuButton("Raporlar", "📊", this::showReportManagement);

        // Ana menü butonları için VBox
        VBox mainButtonBox = new VBox(10);
        mainButtonBox.getChildren().addAll(
            salesButton,
            medicationsButton,
            patientsButton,
            prescriptionsButton,
            reportsButton
        );

        // Alt butonlar için VBox
        MFXButton settingsButton = createMenuButton("Sistem Ayarları", "⚙️", this::showSettingsManagement);
        MFXButton logoutButton = createMenuButton("Güvenli Çıkış", "🔒", this::handleLogout);
        VBox bottomButtonBox = new VBox(10);
        bottomButtonBox.getChildren().addAll(settingsButton, logoutButton);

        // Tüm butonları içeren ana VBox
        VBox buttonBox = new VBox(20);
        buttonBox.setPadding(new Insets(10, 0, 0, 0));
        buttonBox.getChildren().addAll(mainButtonBox, bottomButtonBox);

        // Sol panel içeriğini düzenle
        menu.getChildren().addAll(logoBox, userInfo, buttonBox);
        return menu;
    }

    private MFXButton createMenuButton(String text, String icon, Runnable action) {
        MFXButton button = new MFXButton(icon + "  " + text);
        button.setPrefWidth(210);
        button.setPrefHeight(45);
        button.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-text-fill: #e0e0e0;" + 
            "-fx-font-size: 15px;" + 
            "-fx-font-family: 'Segoe UI';" + 
            "-fx-font-weight: normal;" + 
            "-fx-alignment: CENTER_LEFT;" +
            "-fx-padding: 0 0 0 15;" +
            "-fx-cursor: hand;" +
            "-fx-background-radius: 8;" + 
            "-fx-letter-spacing: 0.5px"
        );
        
        button.setOnMouseEntered(e -> 
            button.setStyle(
                "-fx-background-color: #e53935;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 15px;" +
                "-fx-font-family: 'Segoe UI';" +
                "-fx-font-weight: normal;" +
                "-fx-alignment: CENTER_LEFT;" +
                "-fx-padding: 0 0 0 15;" +
                "-fx-cursor: hand;" +
                "-fx-background-radius: 8;" +
                "-fx-letter-spacing: 0.5px;" +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0, 0, 0)" 
            )
        );
        
        button.setOnMouseExited(e -> 
            button.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: #e0e0e0;" +
                "-fx-font-size: 15px;" +
                "-fx-font-family: 'Segoe UI';" +
                "-fx-font-weight: normal;" +
                "-fx-alignment: CENTER_LEFT;" +
                "-fx-padding: 0 0 0 15;" +
                "-fx-cursor: hand;" +
                "-fx-background-radius: 8;" +
                "-fx-letter-spacing: 0.5px"
            )
        );
        
        button.setOnAction(e -> action.run());
        return button;
    }

    private void showSalesManagement() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new SalesManagement().getContent());
    }

    private void showMedicationManagement() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new MedicationManagement().getContent());
    }

    private void showPatientManagement() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new PatientManagement().getContent());
    }

    private void showPrescriptionManagement() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new PrescriptionManagement().getContent());
    }

    private void showReportManagement() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new ReportManagement().getContent());
    }

    private void showSettingsManagement() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new SettingsManagement(currentUser).getContent());
    }

    private void handleLogout() {
        LoginScreen loginScreen = new LoginScreen(stage);
        loginScreen.show();
    }
}
