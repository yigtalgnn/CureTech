package com.curetech;

import io.github.palexdev.materialfx.controls.MFXButton;
import io.github.palexdev.materialfx.controls.MFXDatePicker;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.scene.Cursor;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Effect;
import javafx.beans.property.SimpleStringProperty;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ReportManagement {
    private VBox content;
    private Effect hoverEffect;
    private Effect normalEffect;

    public ReportManagement() {
        initialize();
    }

    private void initialize() {
        // Efektleri hazırla
        normalEffect = new DropShadow(10, Color.rgb(0, 0, 0, 0.1));
        hoverEffect = new DropShadow(15, Color.rgb(25, 118, 210, 0.3));

        content = new VBox(20);
        content.setStyle("-fx-background-color: white; -fx-padding: 20px;");
        content.setAlignment(Pos.TOP_CENTER);

        // Başlık
        Label titleLabel = new Label("Raporlar");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.web("#212121"));
        titleLabel.setPadding(new Insets(0, 0, 20, 0));

        // İçerik alanı
        VBox contentBox = new VBox(15);
        contentBox.setAlignment(Pos.CENTER);
        contentBox.setPadding(new Insets(30));
        contentBox.setStyle(
            "-fx-background-color: #f5f5f5;" +
            "-fx-background-radius: 10px;" +
            "-fx-border-color: #e0e0e0;" +
            "-fx-border-radius: 10px;"
        );
        contentBox.setMaxWidth(800);

        // Rapor türleri
        contentBox.getChildren().addAll(
            createReportSection("📊  Satış Raporları", 
                "• Günlük satış toplamları\n" +
                "• Haftalık satış grafikleri\n" +
                "• Aylık satış istatistikleri\n" +
                "• Ödeme yöntemlerine göre dağılım",
                () -> showSalesReport()),
            createSeparator(),
            createReportSection("💊  İlaç Raporları",
                "• Stok durumu takibi\n" +
                "• En çok satılan ilaçlar\n" +
                "• Kritik stok seviyeleri\n" +
                "• İlaç kategorilerine göre satışlar",
                () -> showMedicationReport()),
            createSeparator(),
            createReportSection("👥  Hasta Raporları",
                "• Hasta ziyaret sıklığı\n" +
                "• Reçete dağılımları\n" +
                "• Hasta demografik bilgileri\n" +
                "• Hasta memnuniyet oranları",
                () -> showPatientReport()),
            createSeparator(),
            createReportSection("📈  Genel İstatistikler",
                "• Toplam ciro analizi\n" +
                "• Karlılık oranları\n" +
                "• Trend analizleri\n" +
                "• Performans göstergeleri",
                () -> showStatsReport())
        );

        content.getChildren().addAll(titleLabel, contentBox);
    }

    private VBox createReportSection(String title, String details, Runnable onClick) {
        VBox section = new VBox(10);
        section.setPadding(new Insets(15));
        section.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 5px;"
        );
        section.setEffect(normalEffect);
        section.setCursor(Cursor.HAND);

        // Mouse olayları
        section.setOnMouseEntered(e -> {
            section.setEffect(hoverEffect);
            section.setStyle(
                "-fx-background-color: white;" +
                "-fx-background-radius: 5px;" +
                "-fx-scale-x: 1.01;" +
                "-fx-scale-y: 1.01;"
            );
        });

        section.setOnMouseExited(e -> {
            section.setEffect(normalEffect);
            section.setStyle(
                "-fx-background-color: white;" +
                "-fx-background-radius: 5px;" +
                "-fx-scale-x: 1;" +
                "-fx-scale-y: 1;"
            );
        });

        section.setOnMouseClicked(e -> onClick.run());

        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        titleLabel.setTextFill(Color.web("#1976D2"));

        Label detailsLabel = new Label(details);
        detailsLabel.setFont(Font.font("Segoe UI", FontWeight.NORMAL, 14));
        detailsLabel.setTextFill(Color.web("#424242"));
        detailsLabel.setWrapText(true);

        section.getChildren().addAll(titleLabel, detailsLabel);
        return section;
    }

    private VBox createSeparator() {
        VBox separator = new VBox();
        separator.setPrefHeight(1);
        separator.setStyle("-fx-background-color: #e0e0e0;");
        separator.setPadding(new Insets(10, 0, 10, 0));
        return separator;
    }

    private void showSalesReport() {
        Stage stage = new Stage();
        stage.setTitle("Satış Raporları");

        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: white;");

        // Başlık
        Label titleLabel = new Label("Satış Raporları");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.web("#212121"));

        // Tarih seçici
        HBox dateBox = new HBox(10);
        dateBox.setAlignment(Pos.CENTER_LEFT);

        MFXDatePicker startDate = new MFXDatePicker();
        startDate.setFloatingText("Başlangıç Tarihi");
        startDate.setValue(LocalDate.now().minusMonths(1));

        MFXDatePicker endDate = new MFXDatePicker();
        endDate.setFloatingText("Bitiş Tarihi");
        endDate.setValue(LocalDate.now());

        MFXButton filterButton = new MFXButton("Filtrele");
        filterButton.setStyle(
            "-fx-background-color: #2196F3;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 10 20;" +
            "-fx-background-radius: 5;"
        );

        dateBox.getChildren().addAll(startDate, endDate, filterButton);

        // Grafik
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> salesChart = new BarChart<>(xAxis, yAxis);
        salesChart.setTitle("Günlük Satışlar");
        xAxis.setLabel("Tarih");
        yAxis.setLabel("Toplam Satış (TL)");

        // Tablo
        TableView<Sale> salesTable = new TableView<>();
        salesTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Sale, String> dateCol = new TableColumn<>("Tarih");
        dateCol.setCellValueFactory(cellData -> 
            new SimpleStringProperty(
                cellData.getValue().getSaleDate().toLocalDate().format(
                    DateTimeFormatter.ofPattern("dd.MM.yyyy")
                )
            ));

        TableColumn<Sale, String> patientCol = new TableColumn<>("Hasta TC");
        patientCol.setCellValueFactory(new PropertyValueFactory<>("patientTcNo"));

        TableColumn<Sale, Double> totalCol = new TableColumn<>("Toplam (TL)");
        totalCol.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));

        TableColumn<Sale, String> paymentCol = new TableColumn<>("Ödeme Yöntemi");
        paymentCol.setCellValueFactory(new PropertyValueFactory<>("paymentMethod"));

        TableColumn<Sale, String> statusCol = new TableColumn<>("Durum");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        salesTable.getColumns().addAll(dateCol, patientCol, totalCol, paymentCol, statusCol);
        VBox.setVgrow(salesTable, Priority.ALWAYS);

        // Verileri yükle ve güncelle
        Runnable updateReport = () -> {
            try {
                final List<Sale> sales = FileUtils.loadSales();
                final LocalDate start = startDate.getValue();
                final LocalDate end = endDate.getValue();
                
                final List<Sale> filteredSales = sales.stream()
                    .filter(sale -> {
                        LocalDate saleDate = sale.getSaleDate().toLocalDate();
                        return !saleDate.isBefore(start) && !saleDate.isAfter(end);
                    })
                    .collect(Collectors.toList());

                final Map<LocalDate, Double> dailySales = filteredSales.stream()
                    .collect(Collectors.groupingBy(
                        sale -> sale.getSaleDate().toLocalDate(),
                        Collectors.summingDouble(Sale::getTotalAmount)
                    ));

                Platform.runLater(() -> {
                    XYChart.Series<String, Number> series = new XYChart.Series<>();
                    series.setName("Günlük Satışlar");

                    dailySales.forEach((date, total) -> 
                        series.getData().add(new XYChart.Data<>(
                            date.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")), 
                            total
                        )));

                    salesChart.getData().clear();
                    salesChart.getData().add(series);
                    salesTable.setItems(FXCollections.observableArrayList(filteredSales));
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Hata");
                    alert.setHeaderText("Satış Raporları");
                    alert.setContentText("Veriler yüklenirken bir hata oluştu: " + e.getMessage());
                    alert.showAndWait();
                });
            }
        };

        // İlk yükleme
        updateReport.run();

        // Filtre butonuna tıklandığında raporu güncelle
        filterButton.setOnAction(e -> updateReport.run());

        root.getChildren().addAll(titleLabel, dateBox, salesChart, salesTable);

        Scene scene = new Scene(root, 1000, 800);
        stage.setScene(scene);
        stage.show();
    }

    private void showMedicationReport() {
        Stage stage = new Stage();
        stage.setTitle("İlaç Raporları");

        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: white;");

        // Başlık
        Label titleLabel = new Label("İlaç Raporları");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.web("#212121"));

        // Tablo
        TableView<Medication> medicationTable = new TableView<>();
        medicationTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Medication, String> nameCol = new TableColumn<>("İlaç Adı");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Medication, String> categoryCol = new TableColumn<>("Kategori");
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("category"));

        TableColumn<Medication, Integer> stockCol = new TableColumn<>("Stok");
        stockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));

        TableColumn<Medication, Double> priceCol = new TableColumn<>("Fiyat (TL)");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Medication, String> statusCol = new TableColumn<>("Durum");
        statusCol.setCellValueFactory(cellData -> {
            int stock = cellData.getValue().getStock();
            if (stock <= 0) {
                return new SimpleStringProperty("Stokta Yok");
            } else if (stock < 10) {
                return new SimpleStringProperty("Kritik Seviye");
            } else {
                return new SimpleStringProperty("Yeterli Stok");
            }
        });

        medicationTable.getColumns().addAll(nameCol, categoryCol, stockCol, priceCol, statusCol);
        VBox.setVgrow(medicationTable, Priority.ALWAYS);

        // Grafik
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> stockChart = new BarChart<>(xAxis, yAxis);
        stockChart.setTitle("Kategori Bazında Stok Durumu");
        xAxis.setLabel("Kategori");
        yAxis.setLabel("Toplam Stok");

        // Verileri yükle ve güncelle
        Runnable updateReport = () -> {
            try {
                final List<Medication> medications = FileUtils.loadMedications();

                // Kategori bazında stok toplamları
                final Map<String, Integer> categoryStocks = medications.stream()
                    .collect(Collectors.groupingBy(
                        Medication::getType,
                        Collectors.summingInt(Medication::getStock)
                    ));

                Platform.runLater(() -> {
                    XYChart.Series<String, Number> series = new XYChart.Series<>();
                    series.setName("Kategori Stokları");

                    categoryStocks.forEach((category, stock) -> 
                        series.getData().add(new XYChart.Data<>(category, stock)));

                    stockChart.getData().clear();
                    stockChart.getData().add(series);
                    medicationTable.setItems(FXCollections.observableArrayList(medications));
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Hata");
                    alert.setHeaderText("İlaç Raporları");
                    alert.setContentText("Veriler yüklenirken bir hata oluştu: " + e.getMessage());
                    alert.showAndWait();
                });
            }
        };

        // İlk yükleme
        updateReport.run();

        root.getChildren().addAll(titleLabel, stockChart, medicationTable);

        Scene scene = new Scene(root, 1000, 800);
        stage.setScene(scene);
        stage.show();
    }

    private void showPatientReport() {
        Stage stage = new Stage();
        stage.setTitle("Hasta Raporları");

        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: white;");

        // Başlık
        Label titleLabel = new Label("Hasta Raporları");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.web("#212121"));

        // Tablo
        TableView<Patient> patientTable = new TableView<>();
        patientTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Patient, String> tcNoCol = new TableColumn<>("TC No");
        tcNoCol.setCellValueFactory(new PropertyValueFactory<>("tcNo"));

        TableColumn<Patient, String> nameCol = new TableColumn<>("Ad");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));

        TableColumn<Patient, String> surnameCol = new TableColumn<>("Soyad");
        surnameCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));

        TableColumn<Patient, String> phoneCol = new TableColumn<>("Telefon");
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));

        TableColumn<Patient, String> emailCol = new TableColumn<>("E-posta");
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));

        patientTable.getColumns().addAll(tcNoCol, nameCol, surnameCol, phoneCol, emailCol);
        VBox.setVgrow(patientTable, Priority.ALWAYS);

        // Grafik
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> prescriptionChart = new BarChart<>(xAxis, yAxis);
        prescriptionChart.setTitle("Hasta Başına Reçete Sayısı");
        xAxis.setLabel("Hasta");
        yAxis.setLabel("Reçete Sayısı");

        // Verileri yükle ve güncelle
        Runnable updateReport = () -> {
            try {
                final List<Patient> patients = FileUtils.loadPatients();
                final List<Prescription> prescriptions = FileUtils.loadPrescriptions();

                // Hasta başına reçete sayısı
                final Map<String, Long> patientPrescriptions = prescriptions.stream()
                    .collect(Collectors.groupingBy(
                        Prescription::getPatientTcNo,
                        Collectors.counting()
                    ));

                Platform.runLater(() -> {
                    XYChart.Series<String, Number> series = new XYChart.Series<>();
                    series.setName("Reçete Sayıları");

                    patients.forEach(patient -> {
                        String fullName = patient.getName() + " " + patient.getSurname();
                        long prescriptionCount = patientPrescriptions.getOrDefault(patient.getTcNo(), 0L);
                        series.getData().add(new XYChart.Data<>(fullName, prescriptionCount));
                    });

                    prescriptionChart.getData().clear();
                    prescriptionChart.getData().add(series);
                    patientTable.setItems(FXCollections.observableArrayList(patients));
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Hata");
                    alert.setHeaderText("Hasta Raporları");
                    alert.setContentText("Veriler yüklenirken bir hata oluştu: " + e.getMessage());
                    alert.showAndWait();
                });
            }
        };

        // İlk yükleme
        updateReport.run();

        root.getChildren().addAll(titleLabel, prescriptionChart, patientTable);

        Scene scene = new Scene(root, 1000, 800);
        stage.setScene(scene);
        stage.show();
    }

    private void showStatsReport() {
        Stage stage = new Stage();
        stage.setTitle("Genel İstatistikler");

        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: white;");

        // Başlık
        Label titleLabel = new Label("Genel İstatistikler");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.web("#212121"));

        // İstatistik kartları
        HBox statsCards = new HBox(20);
        statsCards.setAlignment(Pos.CENTER);

        // Kart stilleri
        String cardStyle = "-fx-background-color: white; -fx-padding: 20; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 10, 0, 0, 0);";
        String labelStyle = "-fx-font-size: 14; -fx-text-fill: #757575;";
        String valueStyle = "-fx-font-size: 24; -fx-font-weight: bold; -fx-text-fill: #212121;";

        // Toplam Hasta Kartı
        VBox patientCard = new VBox(10);
        patientCard.setStyle(cardStyle);
        patientCard.setAlignment(Pos.CENTER);
        Label patientLabel = new Label("Toplam Hasta");
        patientLabel.setStyle(labelStyle);
        Label patientCount = new Label("0");
        patientCount.setStyle(valueStyle);
        patientCard.getChildren().addAll(patientLabel, patientCount);

        // Toplam İlaç Kartı
        VBox medicationCard = new VBox(10);
        medicationCard.setStyle(cardStyle);
        medicationCard.setAlignment(Pos.CENTER);
        Label medicationLabel = new Label("Toplam İlaç");
        medicationLabel.setStyle(labelStyle);
        Label medicationCount = new Label("0");
        medicationCount.setStyle(valueStyle);
        medicationCard.getChildren().addAll(medicationLabel, medicationCount);

        // Toplam Satış Kartı
        VBox saleCard = new VBox(10);
        saleCard.setStyle(cardStyle);
        saleCard.setAlignment(Pos.CENTER);
        Label saleLabel = new Label("Toplam Satış");
        saleLabel.setStyle(labelStyle);
        Label saleCount = new Label("0");
        saleCount.setStyle(valueStyle);
        saleCard.getChildren().addAll(saleLabel, saleCount);

        // Toplam Gelir Kartı
        VBox revenueCard = new VBox(10);
        revenueCard.setStyle(cardStyle);
        revenueCard.setAlignment(Pos.CENTER);
        Label revenueLabel = new Label("Toplam Gelir (TL)");
        revenueLabel.setStyle(labelStyle);
        Label revenueAmount = new Label("0.00");
        revenueAmount.setStyle(valueStyle);
        revenueCard.getChildren().addAll(revenueLabel, revenueAmount);

        statsCards.getChildren().addAll(patientCard, medicationCard, saleCard, revenueCard);

        // Grafik
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> monthlyChart = new BarChart<>(xAxis, yAxis);
        monthlyChart.setTitle("Aylık Satış ve Gelir Grafiği");
        xAxis.setLabel("Ay");
        yAxis.setLabel("Miktar");

        // Verileri yükle ve güncelle
        Runnable updateReport = () -> {
            try {
                final List<Patient> patients = FileUtils.loadPatients();
                final List<Medication> medications = FileUtils.loadMedications();
                final List<Sale> sales = FileUtils.loadSales();

                // Toplam gelir hesapla
                final double totalRevenue = sales.stream()
                    .mapToDouble(Sale::getTotalAmount)
                    .sum();

                // Aylık satış ve gelir istatistikleri
                final Map<YearMonth, Long> monthlySales = sales.stream()
                    .collect(Collectors.groupingBy(
                        sale -> YearMonth.from(sale.getSaleDate()),
                        Collectors.counting()
                    ));

                final Map<YearMonth, Double> monthlyRevenue = sales.stream()
                    .collect(Collectors.groupingBy(
                        sale -> YearMonth.from(sale.getSaleDate()),
                        Collectors.summingDouble(Sale::getTotalAmount)
                    ));

                Platform.runLater(() -> {
                    // Kart değerlerini güncelle
                    patientCount.setText(String.valueOf(patients.size()));
                    medicationCount.setText(String.valueOf(medications.size()));
                    saleCount.setText(String.valueOf(sales.size()));
                    revenueAmount.setText(String.format("%.2f", totalRevenue));

                    // Grafik verilerini güncelle
                    XYChart.Series<String, Number> saleSeries = new XYChart.Series<>();
                    saleSeries.setName("Satış Sayısı");

                    XYChart.Series<String, Number> revenueSeries = new XYChart.Series<>();
                    revenueSeries.setName("Gelir (TL)");

                    // Son 6 ayın verilerini göster
                    YearMonth currentMonth = YearMonth.now();
                    for (int i = 5; i >= 0; i--) {
                        YearMonth month = currentMonth.minusMonths(i);
                        String monthStr = month.format(DateTimeFormatter.ofPattern("MMMM yyyy"));
                        
                        long monthSaleCount = monthlySales.getOrDefault(month, 0L);
                        double revenue = monthlyRevenue.getOrDefault(month, 0.0);
                        
                        saleSeries.getData().add(new XYChart.Data<>(monthStr, monthSaleCount));
                        revenueSeries.getData().add(new XYChart.Data<>(monthStr, revenue));
                    }

                    monthlyChart.getData().clear();
                    monthlyChart.getData().addAll(saleSeries, revenueSeries);
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Hata");
                    alert.setHeaderText("Genel İstatistikler");
                    alert.setContentText("Veriler yüklenirken bir hata oluştu: " + e.getMessage());
                    alert.showAndWait();
                });
            }
        };

        // İlk yükleme
        updateReport.run();

        root.getChildren().addAll(titleLabel, statsCards, monthlyChart);

        Scene scene = new Scene(root, 1000, 800);
        stage.setScene(scene);
        stage.show();
    }

    private void showComingSoonAlert(String reportType) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Yakında");
        alert.setHeaderText(reportType);
        alert.setContentText("Bu rapor modülü yakında kullanıma açılacaktır.");
        alert.showAndWait();
    }

    public VBox getContent() {
        return content;
    }
}
