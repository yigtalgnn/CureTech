package com.curetech;

import javafx.scene.Scene;
import javafx.scene.Parent;

public class ThemeManager {
    private static final String LIGHT_THEME = """
        .root {
            -fx-background-color: #f5f5f5;
            -fx-text-fill: #212121;
        }
        .label {
            -fx-text-fill: #212121;
        }
        .button {
            -fx-background-color: #1976D2;
            -fx-text-fill: white;
        }
        .text-field {
            -fx-background-color: white;
            -fx-text-fill: #212121;
        }
        .table-view {
            -fx-background-color: white;
        }
        .table-view .column-header {
            -fx-background-color: #1976D2;
        }
        .table-view .column-header .label {
            -fx-text-fill: white;
        }
        .tab-pane {
            -fx-background-color: white;
        }
        .tab {
            -fx-background-color: #e0e0e0;
        }
        .tab:selected {
            -fx-background-color: #1976D2;
        }
        .tab:selected .tab-label {
            -fx-text-fill: white;
        }
    """;

    private static final String DARK_THEME = """
        .root {
            -fx-background-color: #212121;
            -fx-text-fill: #ffffff;
        }
        .label {
            -fx-text-fill: #ffffff;
        }
        .button {
            -fx-background-color: #1976D2;
            -fx-text-fill: white;
        }
        .text-field {
            -fx-background-color: #424242;
            -fx-text-fill: white;
        }
        .table-view {
            -fx-background-color: #424242;
        }
        .table-view .column-header {
            -fx-background-color: #1976D2;
        }
        .table-view .column-header .label {
            -fx-text-fill: white;
        }
        .tab-pane {
            -fx-background-color: #424242;
        }
        .tab {
            -fx-background-color: #616161;
        }
        .tab:selected {
            -fx-background-color: #1976D2;
        }
        .tab:selected .tab-label {
            -fx-text-fill: white;
        }
        .table-view .table-cell {
            -fx-text-fill: white;
        }
        .table-row-cell {
            -fx-background-color: #424242;
        }
        .table-row-cell:selected {
            -fx-background-color: #1976D2;
        }
    """;

    public static void applyTheme(Scene scene, String theme) {
        if (theme.equals("light")) {
            scene.getStylesheets().clear();
            scene.setUserAgentStylesheet(null);
            scene.getRoot().setStyle(LIGHT_THEME);
        } else {
            scene.getStylesheets().clear();
            scene.setUserAgentStylesheet(null);
            scene.getRoot().setStyle(DARK_THEME);
        }
    }

    public static void applyTheme(Parent root, String theme) {
        if (theme.equals("light")) {
            root.setStyle(LIGHT_THEME);
        } else {
            root.setStyle(DARK_THEME);
        }
    }
}
