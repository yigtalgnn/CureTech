package com.curetech;

import io.github.palexdev.materialfx.controls.MFXButton;
import io.github.palexdev.materialfx.controls.MFXTextField;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.paint.Color;

import java.util.List;

public class SettingsManagement {
    private VBox content;
    private User currentUser;
    private TabPane tabPane;
    private TableView<User> userTable;

    public SettingsManagement(User user) {
        this.currentUser = user;
        initialize();
    }

    private void initialize() {
        content = new VBox(20);
        content.setStyle("-fx-background-color: white; -fx-padding: 20px;");

        // Başlık
        Label titleLabel = new Label("Sistem Ayarları");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.web("#212121"));

        // TabPane oluştur
        tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        // Kullanıcı Ayarları tab'ı
        Tab userSettingsTab = new Tab("Kullanıcı Ayarları");
        userSettingsTab.setContent(createUserSettingsContent());

        // Sadece admin için kullanıcı yönetimi tab'ı
        if ("admin".equalsIgnoreCase(currentUser.getRole())) {
            Tab userManagementTab = new Tab("Kullanıcı Yönetimi");
            userManagementTab.setContent(createUserManagementContent());
            tabPane.getTabs().add(userManagementTab);
        }

        tabPane.getTabs().add(userSettingsTab);
        VBox.setVgrow(tabPane, Priority.ALWAYS);

        content.getChildren().addAll(titleLabel, tabPane);
    }

    private VBox createUserSettingsContent() {
        VBox settingsBox = new VBox(20);
        settingsBox.setPadding(new Insets(20));

        // Profil Bilgileri başlığı
        Label profileTitle = new Label("Profil Bilgileri");
        profileTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        profileTitle.setTextFill(Color.web("#424242"));

        // Kullanıcı bilgi alanları
        MFXTextField usernameField = new MFXTextField();
        usernameField.setFloatingText("Kullanıcı Adı");
        usernameField.setText(currentUser.getUsername());
        usernameField.setEditable(false);
        usernameField.setPrefWidth(300);

        MFXTextField nameField = new MFXTextField();
        nameField.setFloatingText("Ad");
        nameField.setText(currentUser.getFirstName());
        nameField.setPrefWidth(300);

        MFXTextField surnameField = new MFXTextField();
        surnameField.setFloatingText("Soyad");
        surnameField.setText(currentUser.getLastName());
        surnameField.setPrefWidth(300);

        // Şifre değiştirme alanları
        Label passwordTitle = new Label("Şifre Değiştir");
        passwordTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        passwordTitle.setTextFill(Color.web("#424242"));
        passwordTitle.setStyle("-fx-padding: 20 0 0 0;");

        PasswordField currentPasswordField = new PasswordField();
        currentPasswordField.setPromptText("Mevcut Şifre");
        currentPasswordField.setPrefWidth(300);

        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("Yeni Şifre");
        newPasswordField.setPrefWidth(300);

        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Yeni Şifre (Tekrar)");
        confirmPasswordField.setPrefWidth(300);

        // Kaydet butonu
        MFXButton saveButton = new MFXButton("Değişiklikleri Kaydet");
        saveButton.setStyle(
            "-fx-background-color: #2196F3;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 10 20;" +
            "-fx-background-radius: 5;"
        );
        saveButton.setPrefWidth(200);

        settingsBox.getChildren().addAll(
            profileTitle,
            usernameField,
            nameField,
            surnameField,
            passwordTitle,
            currentPasswordField,
            newPasswordField,
            confirmPasswordField,
            saveButton
        );

        return settingsBox;
    }

    private VBox createUserManagementContent() {
        VBox managementBox = new VBox(20);
        managementBox.setPadding(new Insets(20));

        // Kullanıcı listesi
        userTable = new TableView<>();
        userTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<User, String> usernameCol = new TableColumn<>("Kullanıcı Adı");
        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));

        TableColumn<User, String> nameCol = new TableColumn<>("Ad");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));

        TableColumn<User, String> surnameCol = new TableColumn<>("Soyad");
        surnameCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));

        TableColumn<User, String> roleCol = new TableColumn<>("Rol");
        roleCol.setCellValueFactory(new PropertyValueFactory<>("role"));

        userTable.getColumns().addAll(usernameCol, nameCol, surnameCol, roleCol);
        VBox.setVgrow(userTable, Priority.ALWAYS);

        // Butonlar
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_LEFT);

        MFXButton addButton = new MFXButton("Yeni Kullanıcı");
        addButton.setStyle(
            "-fx-background-color: #4CAF50;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 10 20;" +
            "-fx-background-radius: 5;"
        );

        MFXButton editButton = new MFXButton("Düzenle");
        editButton.setStyle(
            "-fx-background-color: #FFA000;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 10 20;" +
            "-fx-background-radius: 5;"
        );

        MFXButton deleteButton = new MFXButton("Sil");
        deleteButton.setStyle(
            "-fx-background-color: #F44336;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;" +
            "-fx-padding: 10 20;" +
            "-fx-background-radius: 5;"
        );

        buttonBox.getChildren().addAll(addButton, editButton, deleteButton);

        // Kullanıcı listesini yükle
        refreshUserTable();

        // Event handlers
        addButton.setOnAction(e -> showAddUserDialog());
        editButton.setOnAction(e -> {
            User selectedUser = userTable.getSelectionModel().getSelectedItem();
            if (selectedUser != null) {
                showEditUserDialog(selectedUser);
            }
        });
        deleteButton.setOnAction(e -> {
            User selectedUser = userTable.getSelectionModel().getSelectedItem();
            if (selectedUser != null) {
                showDeleteUserDialog(selectedUser);
            }
        });

        managementBox.getChildren().addAll(userTable, buttonBox);
        return managementBox;
    }

    private void refreshUserTable() {
        List<User> users = FileUtils.loadUsers();
        userTable.setItems(FXCollections.observableArrayList(users));
    }

    private void showAddUserDialog() {
        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle("Yeni Kullanıcı Ekle");
        dialog.setHeaderText(null);

        ButtonType saveButtonType = new ButtonType("Kaydet", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        VBox content = new VBox(10);
        content.setPadding(new Insets(20));

        TextField usernameField = new TextField();
        usernameField.setPromptText("Kullanıcı Adı");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Şifre");

        TextField nameField = new TextField();
        nameField.setPromptText("Ad");

        TextField surnameField = new TextField();
        surnameField.setPromptText("Soyad");

        ComboBox<String> roleComboBox = new ComboBox<>();
        roleComboBox.getItems().addAll("admin", "user");
        roleComboBox.setValue("user");
        roleComboBox.setPromptText("Rol");

        content.getChildren().addAll(
            new Label("Kullanıcı Adı:"), usernameField,
            new Label("Şifre:"), passwordField,
            new Label("Ad:"), nameField,
            new Label("Soyad:"), surnameField,
            new Label("Rol:"), roleComboBox
        );

        dialog.getDialogPane().setContent(content);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                User newUser = new User(
                    usernameField.getText(),
                    passwordField.getText(),
                    nameField.getText(),
                    surnameField.getText()
                );
                newUser.setRole(roleComboBox.getValue());
                return newUser;
            }
            return null;
        });

        dialog.showAndWait().ifPresent(user -> {
            List<User> users = FileUtils.loadUsers();
            users.add(user);
            FileUtils.saveUsers(users);
            refreshUserTable();
        });
    }

    private void showEditUserDialog(User user) {
        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle("Kullanıcı Düzenle");
        dialog.setHeaderText(null);

        ButtonType saveButtonType = new ButtonType("Kaydet", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        VBox content = new VBox(10);
        content.setPadding(new Insets(20));

        TextField usernameField = new TextField(user.getUsername());
        usernameField.setEditable(false);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Yeni Şifre (boş bırakılabilir)");

        TextField nameField = new TextField(user.getFirstName());
        TextField surnameField = new TextField(user.getLastName());

        ComboBox<String> roleComboBox = new ComboBox<>();
        roleComboBox.getItems().addAll("admin", "user");
        roleComboBox.setValue(user.getRole());

        content.getChildren().addAll(
            new Label("Kullanıcı Adı:"), usernameField,
            new Label("Yeni Şifre:"), passwordField,
            new Label("Ad:"), nameField,
            new Label("Soyad:"), surnameField,
            new Label("Rol:"), roleComboBox
        );

        dialog.getDialogPane().setContent(content);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType) {
                String password = passwordField.getText().isEmpty() ? user.getPassword() : passwordField.getText();
                User updatedUser = new User(
                    usernameField.getText(),
                    password,
                    nameField.getText(),
                    surnameField.getText()
                );
                updatedUser.setRole(roleComboBox.getValue());
                return updatedUser;
            }
            return null;
        });

        dialog.showAndWait().ifPresent(updatedUser -> {
            List<User> users = FileUtils.loadUsers();
            users.removeIf(u -> u.getUsername().equals(updatedUser.getUsername()));
            users.add(updatedUser);
            FileUtils.saveUsers(users);
            refreshUserTable();
        });
    }

    private void showDeleteUserDialog(User user) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Kullanıcı Sil");
        alert.setHeaderText(null);
        alert.setContentText("Bu kullanıcıyı silmek istediğinizden emin misiniz?\n" + user.getUsername());

        alert.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                List<User> users = FileUtils.loadUsers();
                users.removeIf(u -> u.getUsername().equals(user.getUsername()));
                FileUtils.saveUsers(users);
                refreshUserTable();
            }
        });
    }

    public VBox getContent() {
        return content;
    }
}
