package com.curetech;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.annotations.SerializedName;

public class Prescription {
    @SerializedName("id")
    private String id;
    
    @SerializedName("patientTcNo")
    private String patientTcNo;
    
    @SerializedName("date")
    private LocalDate date;
    
    @SerializedName("items")
    private List<PrescriptionItem> items;
    
    @SerializedName("doctorName")
    private String doctorName;
    
    @SerializedName("diagnosis")
    private String diagnosis;

    // Default constructor for Gson
    public Prescription() {
        this.items = new ArrayList<>();
    }

    public Prescription(String id, String patientTcNo, LocalDate date, String doctorName, String diagnosis) {
        this.id = id;
        this.patientTcNo = patientTcNo;
        this.date = date;
        this.doctorName = doctorName;
        this.diagnosis = diagnosis;
        this.items = new ArrayList<>();
    }

    // Getters
    public String getId() { return id; }
    public String getPatientTcNo() { return patientTcNo; }
    public LocalDate getDate() { return date; }
    public List<PrescriptionItem> getItems() { return items; }
    public String getDoctorName() { return doctorName; }
    public String getDiagnosis() { return diagnosis; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setPatientTcNo(String patientTcNo) { this.patientTcNo = patientTcNo; }
    public void setDate(LocalDate date) { this.date = date; }
    public void setDoctorName(String doctorName) { this.doctorName = doctorName; }
    public void setDiagnosis(String diagnosis) { this.diagnosis = diagnosis; }
    public void setItems(List<PrescriptionItem> items) { this.items = items; }

    // Helper methods
    public void addItem(PrescriptionItem item) {
        if (items == null) {
            items = new ArrayList<>();
        }
        items.add(item);
    }

    public void removeItem(PrescriptionItem item) {
        if (items != null) {
            items.remove(item);
        }
    }

    @Override
    public String toString() {
        return "Prescription{" +
                "id='" + id + '\'' +
                ", patientTcNo='" + patientTcNo + '\'' +
                ", date=" + date +
                ", doctorName='" + doctorName + '\'' +
                ", diagnosis='" + diagnosis + '\'' +
                ", items=" + items +
                '}';
    }
}
