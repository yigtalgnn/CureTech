package com.curetech;

import io.github.palexdev.materialfx.controls.MFXButton;
import io.github.palexdev.materialfx.controls.MFXPasswordField;
import io.github.palexdev.materialfx.controls.MFXTextField;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.effect.DropShadow;

public class LoginScreen {
    private Stage stage;

    public LoginScreen(Stage stage) {
        this.stage = stage;
    }

    public void show() {
        // Ana container
        StackPane root = new StackPane();
        root.setStyle("-fx-background-color: #FAFAFA;");

        // Login container
        VBox loginBox = new VBox(25);
        loginBox.setAlignment(Pos.CENTER);
        loginBox.setPadding(new Insets(45));
        loginBox.setMaxWidth(340);
        loginBox.setStyle(
            "-fx-background-color: white;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 20, 0, 0, 0);" +
            "-fx-background-radius: 8;"
        );

        // Logo ve başlık
        VBox headerBox = new VBox(6);
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setPadding(new Insets(0, 0, 25, 0));

        Label titleLabel = new Label("CureTech");
        titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 34));
        titleLabel.setTextFill(Color.web("#E53935"));

        Label subtitleLabel = new Label("Eczane Yönetimi");
        subtitleLabel.setFont(Font.font("Segoe UI", FontWeight.NORMAL, 15));
        subtitleLabel.setTextFill(Color.web("#757575"));

        headerBox.getChildren().addAll(titleLabel, subtitleLabel);

        // Form container
        VBox formBox = new VBox(22);
        formBox.setAlignment(Pos.CENTER);

        // Kullanıcı adı alanı
        MFXTextField usernameField = new MFXTextField();
        usernameField.setFloatingText("Kullanıcı Adı");
        usernameField.setPromptText("");
        usernameField.setPrefWidth(290);
        usernameField.setPrefHeight(42);
        usernameField.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-text-fill: #212121;" +
            "-fx-prompt-text-fill: #9E9E9E;" +
            "-fx-font-family: 'Segoe UI';" +
            "-fx-font-size: 13.5px;" +
            "-fx-border-width: 0 0 1 0;" +
            "-fx-border-color: #E0E0E0;"
        );

        // Şifre alanı
        MFXPasswordField passwordField = new MFXPasswordField();
        passwordField.setFloatingText("Şifre");
        passwordField.setPromptText("");
        passwordField.setPrefWidth(290);
        passwordField.setPrefHeight(42);
        passwordField.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-text-fill: #212121;" +
            "-fx-prompt-text-fill: #9E9E9E;" +
            "-fx-font-family: 'Segoe UI';" +
            "-fx-font-size: 13.5px;" +
            "-fx-border-width: 0 0 1 0;" +
            "-fx-border-color: #E0E0E0;"
        );

        // Giriş butonu
        MFXButton loginButton = new MFXButton("GİRİŞ YAP");
        loginButton.setPrefWidth(290);
        loginButton.setPrefHeight(46);
        loginButton.setStyle(
            "-fx-background-color: #E53935;" +
            "-fx-text-fill: white;" +
            "-fx-font-family: 'Segoe UI';" +
            "-fx-font-size: 14px;" +
            "-fx-font-weight: bold;" +
            "-fx-cursor: hand;" +
            "-fx-background-radius: 6"
        );

        // Hata mesajı
        Label errorLabel = new Label();
        errorLabel.setTextFill(Color.web("#D32F2F"));
        errorLabel.setFont(Font.font("Segoe UI", FontWeight.MEDIUM, 12));
        errorLabel.setVisible(false);
        errorLabel.setWrapText(true);
        errorLabel.setMaxWidth(290);
        errorLabel.setAlignment(Pos.CENTER);
        errorLabel.setPadding(new Insets(5, 0, 0, 0));

        // Login işlemi
        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            if (username.isEmpty() || password.isEmpty()) {
                errorLabel.setText("Lütfen kullanıcı adı ve şifre giriniz");
                errorLabel.setVisible(true);
                return;
            }

            User user = FileUtils.validateUser(username, password);
            if (user != null) {
                MainDashboard dashboard = new MainDashboard(stage, user);
                dashboard.show();
            } else {
                errorLabel.setText("Kullanıcı adı veya şifre hatalı");
                errorLabel.setVisible(true);
                passwordField.clear();
            }
        });

        // Enter tuşu ile giriş
        passwordField.setOnAction(e -> loginButton.fire());

        // Hover efektleri
        loginButton.setOnMouseEntered(e -> {
            loginButton.setStyle(
                "-fx-background-color: #D32F2F;" +
                "-fx-text-fill: white;" +
                "-fx-font-family: 'Segoe UI';" +
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;" +
                "-fx-background-radius: 6;" +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 8, 0, 0, 0);"
            );
        });

        loginButton.setOnMouseExited(e -> {
            loginButton.setStyle(
                "-fx-background-color: #E53935;" +
                "-fx-text-fill: white;" +
                "-fx-font-family: 'Segoe UI';" +
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;" +
                "-fx-background-radius: 6"
            );
        });

        // Form elemanlarını ekle
        formBox.getChildren().addAll(
            usernameField,
            passwordField,
            loginButton,
            errorLabel
        );

        // Tüm elemanları ekle
        loginBox.getChildren().addAll(headerBox, formBox);
        root.getChildren().add(loginBox);

        // Sahneyi oluştur
        Scene scene = new Scene(root, 600, 520);
        stage.setTitle("CureTech - Giriş");
        stage.setScene(scene);
        stage.show();
    }
}
