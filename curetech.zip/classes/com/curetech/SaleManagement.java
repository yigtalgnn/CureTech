package com.curetech;

import io.github.palexdev.materialfx.controls.MFXButton;
import io.github.palexdev.materialfx.controls.MFXComboBox;
import io.github.palexdev.materialfx.controls.MFXTextField;
import javafx.animation.PauseTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.util.Duration;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

public class SaleManagement {
    private static SaleManagement instance;
    private final ObservableList<Sale> sales;
    private final ObservableList<SaleItem> cartItems;
    private TableView<Sale> salesTable;
    private TableView<SaleItem> cartTable;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private MFXComboBox<String> patientComboBox;
    private Label totalLabel;
    private Label discountedTotalLabel;
    private ToggleGroup paymentGroup;
    private double currentTotal = 0.0;
    private VBox content;
    private String currentSaleId = "S001"; // Basit bir sayaç, gerçek uygulamada veritabanından alınmalı

    public SaleManagement() {
        sales = FXCollections.observableArrayList();
        cartItems = FXCollections.observableArrayList();
        
        // Örnek veri
        Sale sale = new Sale("S001", "12345678901");
        sale.addItem(new SaleItem("M001", "Aspirin", 2, 15.0));
        sale.completeSale("Nakit");
        sales.add(sale);

        // İçeriği oluştur
        createContent();
        
        // Hastaları yükle
        loadPatients();
    }

    public static VBox getContent() {
        if (instance == null) {
            instance = new SaleManagement();
        }
        return instance.content;
    }

    private VBox createContent() {
        content = new VBox(20);
        content.setPadding(new Insets(20));
        content.setStyle("-fx-background-color: white;");

        // Başlık
        HBox titleBox = new HBox();
        titleBox.setAlignment(Pos.CENTER_LEFT);
        
        Label title = new Label("Satış İşlemleri");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 28));
        title.setTextFill(Color.web("#2A2A2A"));

        titleBox.getChildren().add(title);

        // Ana layout
        HBox mainLayout = new HBox(20);
        mainLayout.setAlignment(Pos.TOP_CENTER);

        // Sol panel - Satış işlemleri
        VBox leftPanel = createSalesPanel();
        
        // Sağ panel - Satış geçmişi
        VBox rightPanel = createHistoryPanel();

        mainLayout.getChildren().addAll(leftPanel, rightPanel);
        content.getChildren().addAll(titleBox, mainLayout);
        return content;
    }

    private VBox createSalesPanel() {
        VBox panel = new VBox(20);
        panel.setPrefWidth(500);
        panel.getStyleClass().add("panel");
        panel.setStyle("-fx-background-color: white; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 2);");
        panel.setPadding(new Insets(20));

        // Hasta seçimi
        VBox patientBox = new VBox(5);
        Label patientLabel = new Label("Hasta Seçimi");
        patientLabel.setFont(Font.font("Roboto", FontWeight.MEDIUM, 14));
        
        patientComboBox = new MFXComboBox<>();
        patientComboBox.setPrefWidth(460);
        patientComboBox.setStyle("-fx-font-size: 14px;");
        
        patientBox.getChildren().addAll(patientLabel, patientComboBox);

        // İlaç arama
        VBox searchBox = new VBox(5);
        Label searchLabel = new Label("İlaç Arama");
        searchLabel.setFont(Font.font("Roboto", FontWeight.MEDIUM, 14));
        
        // Arama kutusu
        MFXTextField searchField = new MFXTextField();
        searchField.setPromptText("İlaç adı veya barkod girin");
        searchField.setPrefWidth(460);
        searchField.setStyle("-fx-font-size: 14px;");
        
        // Sonuç listesi
        ListView<String> resultList = new ListView<>();
        resultList.setPrefWidth(460);
        resultList.setPrefHeight(0);
        resultList.setMaxHeight(200);
        resultList.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #dee2e6;" +
            "-fx-border-width: 1px;" +
            "-fx-border-radius: 5;" +
            "-fx-font-size: 14px;"
        );
        resultList.setVisible(false);
        
        // İlaç listesini yükle
        List<Medication> medications = FileUtils.loadMedications();
        ObservableList<String> medicationNames = FXCollections.observableArrayList();
        for (Medication med : medications) {
            medicationNames.add(med.getName() + " (" + med.getBarkod() + ")");
        }
        
        // Arama yaparken filtreleme
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null || newVal.isEmpty()) {
                resultList.setItems(null);
                resultList.setPrefHeight(0);
                resultList.setVisible(false);
                return;
            }
            
            String searchText = newVal.toLowerCase();
            ObservableList<String> filtered = FXCollections.observableArrayList(
                medicationNames.filtered(name -> name.toLowerCase().contains(searchText))
            );
            
            if (filtered.isEmpty()) {
                resultList.setItems(null);
                resultList.setPrefHeight(0);
                resultList.setVisible(false);
            } else {
                resultList.setItems(filtered);
                resultList.setPrefHeight(Math.min(filtered.size() * 24 + 2, 200));
                resultList.setVisible(true);
            }
        });
        
        // Liste öğesine tıklandığında
        resultList.setOnMouseClicked(e -> {
            String selected = resultList.getSelectionModel().getSelectedItem();
            if (selected != null) {
                handleMedicationSelection(selected, searchField, resultList, medications);
            }
        });
        
        // Enter tuşuna basıldığında ilk sonucu seç
        searchField.setOnAction(e -> {
            if (resultList.getItems() != null && !resultList.getItems().isEmpty()) {
                String selected = resultList.getItems().get(0);
                handleMedicationSelection(selected, searchField, resultList, medications);
            }
        });
        
        // Arama alanı dışına tıklandığında listeyi gizle
        searchField.focusedProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal) {
                PauseTransition pause = new PauseTransition(Duration.millis(200));
                pause.setOnFinished(event -> {
                    if (!resultList.isFocused()) {
                        resultList.setVisible(false);
                    }
                });
                pause.play();
            } else {
                // Arama alanına tıklandığında ve içinde yazı varsa listeyi göster
                if (!searchField.getText().isEmpty()) {
                    resultList.setVisible(true);
                }
            }
        });
        
        // Listeye tıklandığında arama alanının focusunu korumak için
        resultList.setOnMouseEntered(e -> resultList.requestFocus());
        
        searchBox.getChildren().addAll(searchLabel, searchField, resultList);

        // Sepet tablosu
        VBox cartBox = new VBox(5);
        Label cartLabel = new Label("Sepet");
        cartLabel.setFont(Font.font("Roboto", FontWeight.MEDIUM, 14));
        
        cartTable = new TableView<>();
        cartTable.setItems(cartItems);
        cartTable.setPrefHeight(300);
        cartTable.setStyle("-fx-font-family: 'Roboto';");

        TableColumn<SaleItem, String> nameCol = new TableColumn<>("İlaç Adı");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("medicationName"));
        nameCol.setPrefWidth(200);

        TableColumn<SaleItem, Integer> quantityCol = new TableColumn<>("Adet");
        quantityCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        quantityCol.setPrefWidth(100);

        TableColumn<SaleItem, Double> priceCol = new TableColumn<>("Fiyat");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("unitPrice"));
        priceCol.setPrefWidth(100);
        priceCol.setCellFactory(column -> new TableCell<SaleItem, Double>() {
            @Override
            protected void updateItem(Double item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? null : String.format("%.2f ₺", item));
            }
        });

        cartTable.getColumns().addAll(nameCol, quantityCol, priceCol);
        cartBox.getChildren().addAll(cartLabel, cartTable);

        // Toplam ve butonlar
        VBox actionsBox = new VBox(10);
        actionsBox.setAlignment(Pos.CENTER_RIGHT);

        // Ödeme seçenekleri
        HBox paymentBox = new HBox(10);
        paymentBox.setAlignment(Pos.CENTER_RIGHT);
        
        paymentGroup = new ToggleGroup();
        
        RadioButton cashRadio = new RadioButton("Nakit");
        cashRadio.setToggleGroup(paymentGroup);
        cashRadio.setUserData("Nakit");
        cashRadio.setSelected(true);
        
        RadioButton creditRadio = new RadioButton("Kredi Kartı");
        creditRadio.setToggleGroup(paymentGroup);
        creditRadio.setUserData("Kredi Kartı");
        
        RadioButton insuranceRadio = new RadioButton("Sigorta");
        insuranceRadio.setToggleGroup(paymentGroup);
        insuranceRadio.setUserData("Sigorta");
        
        paymentBox.getChildren().addAll(cashRadio, creditRadio, insuranceRadio);
        
        // Toplam tutarlar
        VBox totalsBox = new VBox(5);
        totalsBox.setAlignment(Pos.CENTER_RIGHT);
        
        totalLabel = new Label("Toplam: 0.00 ₺");
        totalLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 18));
        totalLabel.setTextFill(Color.web("#2A2A2A"));
        
        discountedTotalLabel = new Label("");
        discountedTotalLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 16));
        discountedTotalLabel.setTextFill(Color.web("#28a745"));
        
        totalsBox.getChildren().addAll(totalLabel, discountedTotalLabel);

        // Ödeme yöntemi değiştiğinde
        paymentGroup.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                updateTotal();
            }
        });

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);

        MFXButton clearButton = new MFXButton("Sepeti Temizle");
        clearButton.setStyle("-fx-background-color: #dc3545; -fx-text-fill: white;");
        clearButton.setOnAction(e -> clearCart());
        
        MFXButton completeButton = new MFXButton("Satışı Tamamla");
        completeButton.setStyle("-fx-background-color: #28a745; -fx-text-fill: white;");
        completeButton.setOnAction(e -> completeSale());

        buttonBox.getChildren().addAll(clearButton, completeButton);
        actionsBox.getChildren().addAll(paymentBox, totalsBox, buttonBox);

        panel.getChildren().addAll(
            patientBox,
            searchBox,
            cartBox,
            actionsBox
        );

        return panel;
    }

    private void handleMedicationSelection(String selected, MFXTextField searchField, ListView<String> resultList, List<Medication> medications) {
        try {
            String barkod = selected.substring(selected.lastIndexOf("(") + 1, selected.lastIndexOf(")"));
            Optional<Medication> med = medications.stream()
                .filter(m -> m.getBarkod().equals(barkod))
                .findFirst();
                
            if (med.isPresent()) {
                if (med.get().getStock() <= 0) {
                    showError("Stok Yetersiz", "Bu ilaç stokta bulunmamaktadır!");
                } else {
                    showAddToCartDialog(med.get());
                }
            }
        } catch (Exception ex) {
            showError("Hata", "İlaç seçiminde bir hata oluştu!");
        } finally {
            searchField.clear();
            resultList.setItems(null);
            resultList.setPrefHeight(0);
            resultList.setVisible(false);
        }
    }

    private VBox createHistoryPanel() {
        VBox panel = new VBox(20);
        panel.setPrefWidth(500);
        panel.getStyleClass().add("panel");
        panel.setStyle("-fx-background-color: white; -fx-background-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 2);");
        panel.setPadding(new Insets(20));

        // Başlık ve arama
        VBox headerBox = new VBox(5);
        Label historyLabel = new Label("Satış Geçmişi");
        historyLabel.setFont(Font.font("Roboto", FontWeight.MEDIUM, 14));

        MFXTextField searchHistory = new MFXTextField();
        searchHistory.setPromptText("Satış no veya hasta TC ile arama yapın");
        searchHistory.setPrefWidth(460);
        searchHistory.setStyle("-fx-font-size: 14px;");
        searchHistory.setOnAction(e -> searchSales(searchHistory.getText()));

        headerBox.getChildren().addAll(historyLabel, searchHistory);

        // Satış geçmişi tablosu
        salesTable = new TableView<>();
        salesTable.setItems(sales);
        salesTable.setPrefHeight(400);
        salesTable.setStyle("-fx-font-family: 'Roboto';");

        TableColumn<Sale, String> idColumn = new TableColumn<>("Satış No");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        idColumn.setPrefWidth(80);

        TableColumn<Sale, String> patientColumn = new TableColumn<>("Hasta TC");
        patientColumn.setCellValueFactory(new PropertyValueFactory<>("patientTcNo"));
        patientColumn.setPrefWidth(100);

        TableColumn<Sale, LocalDateTime> dateColumn = new TableColumn<>("Tarih");
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("saleDate"));
        dateColumn.setPrefWidth(130);
        dateColumn.setCellFactory(column -> new TableCell<Sale, LocalDateTime>() {
            @Override
            protected void updateItem(LocalDateTime item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : formatter.format(item));
            }
        });

        TableColumn<Sale, Double> amountColumn = new TableColumn<>("Tutar");
        amountColumn.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));
        amountColumn.setPrefWidth(80);
        amountColumn.setCellFactory(column -> new TableCell<Sale, Double>() {
            @Override
            protected void updateItem(Double item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : String.format("%.2f ₺", item));
            }
        });

        TableColumn<Sale, String> statusColumn = new TableColumn<>("Durum");
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusColumn.setPrefWidth(80);

        salesTable.getColumns().addAll(
            idColumn, patientColumn, dateColumn, 
            amountColumn, statusColumn
        );

        panel.getChildren().addAll(headerBox, salesTable);
        return panel;
    }

    private void loadPatients() {
        List<Patient> patients = FileUtils.loadPatients();
        ObservableList<String> patientIds = FXCollections.observableArrayList();
        for (Patient patient : patients) {
            patientIds.add(patient.getTcNo() + " - " + patient.getName() + " " + patient.getSurname());
        }
        patientComboBox.setItems(patientIds);
    }

    private void showAddToCartDialog(Medication medication) {
        Dialog<Integer> dialog = new Dialog<>();
        dialog.setTitle("İlaç Ekle");
        dialog.setHeaderText("Sepete eklenecek " + medication.getName() + " adedini girin\nMevcut Stok: " + medication.getStock());

        ButtonType addButton = new ButtonType("Ekle", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(addButton, ButtonType.CANCEL);

        MFXTextField quantityField = new MFXTextField();
        quantityField.setPromptText("Adet");
        quantityField.setText("1");
        
        dialog.getDialogPane().setContent(quantityField);
        
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == addButton) {
                try {
                    int quantity = Integer.parseInt(quantityField.getText());
                    if (quantity > medication.getStock()) {
                        showError("Stok Yetersiz", "Stokta sadece " + medication.getStock() + " adet bulunmaktadır!");
                        return null;
                    }
                    return quantity;
                } catch (NumberFormatException e) {
                    return null;
                }
            }
            return null;
        });

        Optional<Integer> result = dialog.showAndWait();
        result.ifPresent(quantity -> {
            if (quantity > 0) {
                SaleItem item = new SaleItem(
                    medication.getBarkod(),
                    medication.getName(),
                    quantity,
                    medication.getPrice()
                );
                cartItems.add(item);
                updateTotal();
            }
        });
    }

    private void updateTotal() {
        currentTotal = cartItems.stream()
            .mapToDouble(item -> item.getQuantity() * item.getUnitPrice())
            .sum();
        
        totalLabel.setText(String.format("Toplam: %.2f ₺", currentTotal));
        
        Toggle selectedPayment = paymentGroup.getSelectedToggle();
        if (selectedPayment != null && selectedPayment.getUserData().equals("Sigorta")) {
            double discountedTotal = currentTotal * 0.9; // %10 indirim
            discountedTotalLabel.setText(String.format("İndirimli Toplam: %.2f ₺", discountedTotal));
            discountedTotalLabel.setVisible(true);
        } else {
            discountedTotalLabel.setText("");
            discountedTotalLabel.setVisible(false);
        }
    }

    private void clearCart() {
        cartItems.clear();
        updateTotal();
    }

    private void completeSale() {
        if (cartItems.isEmpty()) {
            showError("Hata", "Sepet boş!");
            return;
        }

        String selectedPatient = patientComboBox.getValue();
        if (selectedPatient == null || selectedPatient.isEmpty()) {
            showError("Hata", "Lütfen hasta seçin!");
            return;
        }

        // Stok kontrolü
        List<Medication> medications = FileUtils.loadMedications();
        for (SaleItem item : cartItems) {
            Optional<Medication> med = medications.stream()
                .filter(m -> m.getBarkod().equals(item.getMedicationId()))
                .findFirst();
            
            if (med.isPresent()) {
                Medication medication = med.get();
                if (medication.getStock() < item.getQuantity()) {
                    showError("Stok Yetersiz", medication.getName() + " için stokta sadece " + medication.getStock() + " adet bulunmaktadır!");
                    return;
                }
            }
        }

        String tcNo = selectedPatient.split(" - ")[0];
        Sale sale = new Sale(generateNextSaleId(), tcNo);
        cartItems.forEach(sale::addItem);
        
        Toggle selectedPayment = paymentGroup.getSelectedToggle();
        if (selectedPayment != null) {
            String paymentMethod = (String) selectedPayment.getUserData();
            sale.completeSale(paymentMethod);
            
            // Sigorta indirimi varsa toplam tutarı güncelle
            if (paymentMethod.equals("Sigorta")) {
                sale.setTotalAmount(sale.getTotalAmount() * 0.9);
            }
            
            // Stokları güncelle
            updateMedicationStocks();
            
            sales.add(sale);
            clearCart();
            
            showSuccess("Başarılı", "Satış başarıyla tamamlandı!");
        }
    }

    private void updateMedicationStocks() {
        List<Medication> medications = FileUtils.loadMedications();
        boolean stockUpdated = false;

        for (SaleItem item : cartItems) {
            for (Medication med : medications) {
                if (med.getBarkod().equals(item.getMedicationId())) {
                    med.setStock(med.getStock() - item.getQuantity());
                    stockUpdated = true;
                    
                    // Minimum stok kontrolü
                    if (med.getStock() <= med.getMinStock()) {
                        showWarning("Düşük Stok", med.getName() + " için stok seviyesi minimum değerin altına düştü!\nMevcut Stok: " + med.getStock());
                    }
                    break;
                }
            }
        }

        if (stockUpdated) {
            FileUtils.saveMedications(medications);
        }
    }

    private String generateNextSaleId() {
        int id = Integer.parseInt(currentSaleId.substring(1)) + 1;
        currentSaleId = String.format("S%03d", id);
        return currentSaleId;
    }

    private void searchSales(String query) {
        if (query == null || query.trim().isEmpty()) {
            salesTable.setItems(sales);
            return;
        }

        ObservableList<Sale> filtered = sales.filtered(sale ->
            sale.getId().toLowerCase().contains(query.toLowerCase()) ||
            sale.getPatientTcNo().toLowerCase().contains(query.toLowerCase())
        );
        salesTable.setItems(filtered);
    }

    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void showSuccess(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void showWarning(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
