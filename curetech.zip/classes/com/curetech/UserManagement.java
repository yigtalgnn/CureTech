package com.curetech;

import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.paint.Color;

public class UserManagement {
    private VBox content;

    public VBox getContent() {
        if (content == null) {
            content = new VBox(20);
            content.setStyle("-fx-background-color: white; -fx-padding: 20px;");

            Label titleLabel = new Label("Kullanıcı Yönetimi");
            titleLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
            titleLabel.setTextFill(Color.web("#212121"));

            content.getChildren().addAll(titleLabel);
        }
        return content;
    }
}
