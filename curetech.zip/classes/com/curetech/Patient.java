package com.curetech;

public class Patient {
    private String tcNo;
    private String name;
    private String surname;
    private String phone;
    private String address;
    private String birthDate;

    public Patient(String tcNo, String name, String surname, String phone, String address, String birthDate) {
        this.tcNo = tcNo;
        this.name = name;
        this.surname = surname;
        this.phone = phone;
        this.address = address;
        this.birthDate = birthDate;
    }

    // Getter metodları
    public String getTcNo() {
        return tcNo;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getBirthDate() {
        return birthDate;
    }

    // Setter metodları
    public void setTcNo(String tcNo) {
        this.tcNo = tcNo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }
}
