package com.curetech;

public class PrescriptionItem {
    private String medicationBarkod;
    private int quantity;
    private String usage;
    private int period;

    public PrescriptionItem(String medicationBarkod, int quantity, String usage, int period) {
        this.medicationBarkod = medicationBarkod;
        this.quantity = quantity;
        this.usage = usage;
        this.period = period;
    }

    // Getters
    public String getMedicationBarkod() { return medicationBarkod; }
    public int getQuantity() { return quantity; }
    public String getUsage() { return usage; }
    public int getPeriod() { return period; }

    // Setters
    public void setMedicationBarkod(String medicationBarkod) { this.medicationBarkod = medicationBarkod; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setUsage(String usage) { this.usage = usage; }
    public void setPeriod(int period) { this.period = period; }
}
