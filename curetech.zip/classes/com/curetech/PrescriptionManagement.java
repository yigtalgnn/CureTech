package com.curetech;

import io.github.palexdev.materialfx.controls.*;
import io.github.palexdev.materialfx.effects.DepthLevel;
import io.github.palexdev.materialfx.effects.MFXDepthManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PrescriptionManagement {
    private static ObservableList<Prescription> prescriptions;
    private static TableView<Prescription> tableView;

    private static void initializePrescriptions() {
        if (prescriptions == null) {
            System.out.println("Reçeteler yükleniyor...");
            List<Prescription> loadedPrescriptions = FileUtils.loadPrescriptions();
            System.out.println("Yüklenen reçete sayısı: " + loadedPrescriptions.size());
            
            if (loadedPrescriptions.isEmpty()) {
                System.out.println("Örnek reçeteler oluşturuluyor...");
                loadedPrescriptions = new ArrayList<>();
                loadedPrescriptions.add(new Prescription("RX001", "12345678901", LocalDate.now(), "Dr. Ahmet Yılmaz", "Grip"));
                loadedPrescriptions.add(new Prescription("RX002", "98765432109", LocalDate.now().minusDays(1), "Dr. Mehmet Öz", "Migren"));
                loadedPrescriptions.add(new Prescription("RX003", "45678901234", LocalDate.now().minusDays(2), "Dr. Ayşe Demir", "Alerji"));
                FileUtils.savePrescriptions(loadedPrescriptions);
                System.out.println("Örnek reçeteler kaydedildi. Sayı: " + loadedPrescriptions.size());
            }
            
            prescriptions = FXCollections.observableArrayList(loadedPrescriptions);
            System.out.println("Observable liste oluşturuldu. Sayı: " + prescriptions.size());
        }
    }

    public static VBox getContent() {
        System.out.println("getContent() çağrıldı");
        initializePrescriptions();
        System.out.println("Mevcut reçete sayısı: " + prescriptions.size());
        
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));
        content.setStyle("-fx-background-color: white;");

        // Başlık ve Arama Bölümü
        VBox headerBox = createHeaderBox();
        
        // Tablo
        tableView = createTableView();
        
        // Alt Bilgi Bölümü
        HBox statsBox = createStatsBox();

        content.getChildren().addAll(headerBox, tableView, statsBox);
        return content;
    }

    private static VBox createHeaderBox() {
        VBox headerBox = new VBox(15);
        headerBox.setStyle("-fx-background-color: white; -fx-border-color: #E0E0E0; -fx-border-width: 0 0 1 0;");
        headerBox.setPadding(new Insets(0, 0, 15, 0));

        // Başlık
        Label title = new Label("Reçete Yönetimi");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 24));
        title.setTextFill(Color.web("#1A1A1A"));

        // Buton ve Arama Satırı
        HBox actionBox = new HBox(15);
        actionBox.setAlignment(Pos.CENTER_LEFT);

        // Arama Alanı
        TextField searchField = new TextField();
        searchField.setPromptText("Reçete Ara...");
        searchField.setPrefWidth(300);
        searchField.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #E0E0E0;" +
            "-fx-border-width: 1px;" +
            "-fx-border-radius: 3px;" +
            "-fx-padding: 8px;" +
            "-fx-font-size: 14px;"
        );

        // Yeni Reçete Butonu
        MFXButton addButton = new MFXButton("+ Yeni Reçete");
        addButton.setStyle(
            "-fx-background-color: #4CAF50;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );
        addButton.setOnAction(e -> showAddPrescriptionDialog());

        // Arama işlevselliği
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.isEmpty()) {
                tableView.setItems(prescriptions);
            } else {
                ObservableList<Prescription> filteredList = FXCollections.observableArrayList();
                for (Prescription prescription : prescriptions) {
                    if (prescription.getPatientTcNo().toLowerCase().contains(newValue.toLowerCase()) ||
                        prescription.getId().toLowerCase().contains(newValue.toLowerCase()) ||
                        prescription.getDoctorName().toLowerCase().contains(newValue.toLowerCase()) ||
                        prescription.getDiagnosis().toLowerCase().contains(newValue.toLowerCase())) {
                        filteredList.add(prescription);
                    }
                }
                tableView.setItems(filteredList);
            }
        });

        actionBox.getChildren().addAll(searchField, addButton);
        headerBox.getChildren().addAll(title, actionBox);
        return headerBox;
    }

    private static TableView<Prescription> createTableView() {
        TableView<Prescription> table = new TableView<>();
        table.setItems(prescriptions);
        table.setPrefHeight(500);
        table.setStyle("-fx-font-family: 'Roboto';");

        // Sütunlar
        TableColumn<Prescription, String> idColumn = new TableColumn<>("Reçete No");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        idColumn.setPrefWidth(120);

        TableColumn<Prescription, String> patientColumn = new TableColumn<>("Hasta TC No");
        patientColumn.setCellValueFactory(new PropertyValueFactory<>("patientTcNo"));
        patientColumn.setPrefWidth(120);

        TableColumn<Prescription, LocalDate> dateColumn = new TableColumn<>("Tarih");
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        dateColumn.setPrefWidth(120);

        TableColumn<Prescription, String> doctorColumn = new TableColumn<>("Doktor");
        doctorColumn.setCellValueFactory(new PropertyValueFactory<>("doctorName"));
        doctorColumn.setPrefWidth(150);

        TableColumn<Prescription, String> diagnosisColumn = new TableColumn<>("Tanı");
        diagnosisColumn.setCellValueFactory(new PropertyValueFactory<>("diagnosis"));
        diagnosisColumn.setPrefWidth(200);

        TableColumn<Prescription, Void> actionsColumn = new TableColumn<>("İşlemler");
        actionsColumn.setPrefWidth(200);
        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final MFXButton viewButton = new MFXButton("Görüntüle");
            private final MFXButton deleteButton = new MFXButton("Sil");

            {
                viewButton.setStyle(
                    "-fx-background-color: #2196F3;" +
                    "-fx-text-fill: white;" +
                    "-fx-font-size: 12px;"
                );
                viewButton.setPrefWidth(80);

                deleteButton.setStyle(
                    "-fx-background-color: #F44336;" +
                    "-fx-text-fill: white;" +
                    "-fx-font-size: 12px;"
                );
                deleteButton.setPrefWidth(80);

                HBox box = new HBox(5);
                box.setAlignment(Pos.CENTER);
                box.getChildren().addAll(viewButton, deleteButton);
                setGraphic(box);

                viewButton.setOnAction(event -> {
                    Prescription prescription = getTableView().getItems().get(getIndex());
                    showViewPrescriptionDialog(prescription);
                });

                deleteButton.setOnAction(event -> {
                    Prescription prescription = getTableView().getItems().get(getIndex());
                    deletePrescription(prescription);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : getGraphic());
            }
        });

        table.getColumns().addAll(
            idColumn, patientColumn, dateColumn, 
            doctorColumn, diagnosisColumn, actionsColumn
        );

        return table;
    }

    private static HBox createStatsBox() {
        HBox statsBox = new HBox(20);
        statsBox.setPadding(new Insets(20));
        statsBox.setStyle("-fx-background-color: #f5f5f5; -fx-background-radius: 5;");
        statsBox.setAlignment(Pos.CENTER);

        // İstatistik kartları
        VBox totalBox = createStatCard("Toplam Reçete", String.valueOf(prescriptions.size()), "#1976D2");
        VBox todayBox = createStatCard("Bugünkü Reçete", "0", "#4CAF50");
        VBox activeBox = createStatCard("Aktif Reçete", String.valueOf(prescriptions.size()), "#FF9800");

        statsBox.getChildren().addAll(totalBox, todayBox, activeBox);
        return statsBox;
    }

    private static VBox createStatCard(String title, String value, String color) {
        VBox card = new VBox(5);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(15));
        card.setStyle("-fx-background-color: white; -fx-background-radius: 5;");
        card.setPrefWidth(200);

        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("Roboto", FontWeight.NORMAL, 14));
        titleLabel.setTextFill(Color.web("#757575"));

        Label valueLabel = new Label(value);
        valueLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 24));
        valueLabel.setTextFill(Color.web(color));

        card.getChildren().addAll(valueLabel, titleLabel);
        return card;
    }

    private static void showAddPrescriptionDialog() {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initStyle(StageStyle.UNDECORATED);

        VBox dialogContent = new VBox(20);
        dialogContent.setPadding(new Insets(20));
        dialogContent.setStyle("-fx-background-color: white;");

        // Dialog başlığı
        Label title = new Label("Yeni Reçete Ekle");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 20));

        // Form alanları
        MFXTextField idField = new MFXTextField();
        idField.setPromptText("Reçete No");
        idField.setPrefWidth(300);

        MFXTextField patientField = new MFXTextField();
        patientField.setPromptText("Hasta TC No");
        patientField.setPrefWidth(300);

        MFXDatePicker dateField = new MFXDatePicker();
        dateField.setPromptText("Tarih");
        dateField.setPrefWidth(300);

        MFXTextField doctorField = new MFXTextField();
        doctorField.setPromptText("Doktor Adı");
        doctorField.setPrefWidth(300);

        MFXTextField diagnosisField = new MFXTextField();
        diagnosisField.setPromptText("Tanı");
        diagnosisField.setPrefWidth(300);

        // Butonlar
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);

        MFXButton cancelButton = new MFXButton("İptal");
        cancelButton.setStyle(
            "-fx-background-color: #757575;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );
        cancelButton.setOnAction(e -> dialog.close());

        MFXButton saveButton = new MFXButton("Kaydet");
        saveButton.setStyle(
            "-fx-background-color: #4CAF50;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );
        saveButton.setOnAction(e -> {
            Prescription newPrescription = new Prescription(
                idField.getText(),
                patientField.getText(),
                dateField.getValue(),
                doctorField.getText(),
                diagnosisField.getText()
            );
            prescriptions.add(newPrescription);
            FileUtils.savePrescriptions(new ArrayList<>(prescriptions));
            dialog.close();
        });

        buttonBox.getChildren().addAll(cancelButton, saveButton);

        dialogContent.getChildren().addAll(
            title,
            idField,
            patientField,
            dateField,
            doctorField,
            diagnosisField,
            buttonBox
        );

        Scene scene = new Scene(dialogContent);
        dialog.setScene(scene);
        dialog.show();
    }

    private static void showViewPrescriptionDialog(Prescription prescription) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initStyle(StageStyle.UNDECORATED);

        VBox dialogContent = new VBox(20);
        dialogContent.setPadding(new Insets(20));
        dialogContent.setStyle("-fx-background-color: white;");

        // Dialog başlığı
        Label title = new Label("Reçete Detayları");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 20));

        // Reçete bilgileri
        VBox infoBox = new VBox(10);
        infoBox.setStyle("-fx-background-color: #f5f5f5; -fx-padding: 10; -fx-background-radius: 5;");

        Label idLabel = new Label("Reçete No: " + prescription.getId());
        Label patientLabel = new Label("Hasta TC No: " + prescription.getPatientTcNo());
        Label dateLabel = new Label("Tarih: " + prescription.getDate());
        Label doctorLabel = new Label("Doktor: " + prescription.getDoctorName());
        Label diagnosisLabel = new Label("Tanı: " + prescription.getDiagnosis());

        infoBox.getChildren().addAll(
            idLabel, patientLabel, dateLabel,
            doctorLabel, diagnosisLabel
        );

        // Kapat butonu
        MFXButton closeButton = new MFXButton("Kapat");
        closeButton.setStyle(
            "-fx-background-color: #757575;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );
        closeButton.setOnAction(e -> dialog.close());

        dialogContent.getChildren().addAll(title, infoBox, closeButton);

        Scene scene = new Scene(dialogContent);
        dialog.setScene(scene);
        dialog.show();
    }

    private static void deletePrescription(Prescription prescription) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Reçete Sil");
        alert.setHeaderText("Reçete Silme Onayı");
        alert.setContentText("Bu reçeteyi silmek istediğinizden emin misiniz?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            prescriptions.remove(prescription);
            FileUtils.savePrescriptions(new ArrayList<>(prescriptions));
        }
    }
}
