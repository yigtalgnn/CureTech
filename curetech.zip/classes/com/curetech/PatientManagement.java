package com.curetech;

import io.github.palexdev.materialfx.controls.*;
import io.github.palexdev.materialfx.effects.DepthLevel;
import io.github.palexdev.materialfx.effects.MFXDepthManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.util.Optional;
import java.util.ArrayList;
import java.io.*;

public class PatientManagement {
    private static final ObservableList<Patient> patients = FXCollections.observableArrayList();
    private static TableView<Patient> tableView;

    public static ObservableList<Patient> getPatients() {
        return patients;
    }

    static {
        // Uygulama başladığında verileri yükle
        patients.addAll(FileUtils.loadPatients());
    }

    public static VBox getContent() {
        // Ana container
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));
        content.setStyle("-fx-background-color: #f5f5f5;");

        // Header
        VBox headerBox = createHeaderBox();
        content.getChildren().add(headerBox);

        // Tablo
        tableView = new TableView<>();
        tableView.setItems(patients);
        tableView.setPrefHeight(500);
        tableView.setStyle("-fx-font-family: 'Roboto';");

        // Sütunlar
        TableColumn<Patient, String> tcNoColumn = new TableColumn<>("TC No");
        tcNoColumn.setCellValueFactory(new PropertyValueFactory<>("tcNo"));
        tcNoColumn.setPrefWidth(120);

        TableColumn<Patient, String> nameColumn = new TableColumn<>("Ad");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameColumn.setPrefWidth(120);

        TableColumn<Patient, String> surnameColumn = new TableColumn<>("Soyad");
        surnameColumn.setCellValueFactory(new PropertyValueFactory<>("surname"));
        surnameColumn.setPrefWidth(120);

        TableColumn<Patient, String> phoneColumn = new TableColumn<>("Telefon");
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        phoneColumn.setPrefWidth(120);

        TableColumn<Patient, String> addressColumn = new TableColumn<>("Adres");
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        addressColumn.setPrefWidth(200);

        TableColumn<Patient, String> birthDateColumn = new TableColumn<>("Doğum Tarihi");
        birthDateColumn.setCellValueFactory(new PropertyValueFactory<>("birthDate"));
        birthDateColumn.setPrefWidth(120);

        TableColumn<Patient, Void> actionsColumn = new TableColumn<>("İşlemler");
        actionsColumn.setPrefWidth(200);
        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final MFXButton editButton = new MFXButton("Düzenle");
            private final MFXButton deleteButton = new MFXButton("Sil");

            {
                editButton.setStyle(
                    "-fx-background-color: #2196F3;" +
                    "-fx-text-fill: white;" +
                    "-fx-font-family: 'Roboto';" +
                    "-fx-font-size: 12px;"
                );
                editButton.setPrefWidth(80);

                deleteButton.setStyle(
                    "-fx-background-color: #F44336;" +
                    "-fx-text-fill: white;" +
                    "-fx-font-family: 'Roboto';" +
                    "-fx-font-size: 12px;"
                );
                deleteButton.setPrefWidth(80);

                HBox box = new HBox(5);
                box.setAlignment(Pos.CENTER);
                box.getChildren().addAll(editButton, deleteButton);
                setGraphic(box);

                editButton.setOnAction(event -> {
                    Patient patient = getTableView().getItems().get(getIndex());
                    showEditPatientDialog(patient);
                });

                deleteButton.setOnAction(event -> {
                    Patient patient = getTableView().getItems().get(getIndex());
                    deletePatient(patient);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : getGraphic());
            }
        });

        tableView.getColumns().addAll(
            tcNoColumn, nameColumn, surnameColumn, phoneColumn,
            addressColumn, birthDateColumn, actionsColumn
        );

        content.getChildren().add(tableView);

        return content;
    }

    private static VBox createHeaderBox() {
        VBox headerBox = new VBox(15);
        headerBox.setStyle("-fx-background-color: white; -fx-border-color: #E0E0E0; -fx-border-width: 0 0 1 0;");
        headerBox.setPadding(new Insets(0, 0, 15, 0));

        // Başlık
        Label title = new Label("Hasta Yönetimi");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 24));
        title.setTextFill(Color.web("#1A1A1A"));

        // Buton ve Arama Satırı
        HBox actionBox = new HBox(15);
        actionBox.setAlignment(Pos.CENTER_LEFT);

        // Arama Alanı
        TextField searchField = new TextField();
        searchField.setPromptText("TC No veya isim ile arama yapın");
        searchField.setPrefWidth(460);
        searchField.setStyle("-fx-font-size: 14px;");

        // Yeni Hasta Butonu
        MFXButton addButton = new MFXButton("+ Yeni Hasta");
        addButton.setStyle(
            "-fx-background-color: #4CAF50;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );
        addButton.setOnAction(e -> showAddPatientDialog());

        // Arama işlevselliği
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.isEmpty()) {
                tableView.setItems(patients);
            } else {
                ObservableList<Patient> filteredList = FXCollections.observableArrayList();
                for (Patient patient : patients) {
                    String fullName = patient.getName() + " " + patient.getSurname();
                    if (patient.getTcNo().toLowerCase().contains(newValue.toLowerCase()) ||
                        fullName.toLowerCase().contains(newValue.toLowerCase()) ||
                        patient.getPhone().toLowerCase().contains(newValue.toLowerCase())) {
                        filteredList.add(patient);
                    }
                }
                tableView.setItems(filteredList);
            }
        });

        actionBox.getChildren().addAll(searchField, addButton);
        headerBox.getChildren().addAll(title, actionBox);
        return headerBox;
    }

    private static void showAddPatientDialog() {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initStyle(StageStyle.UNDECORATED);

        VBox dialogContent = new VBox(20);
        dialogContent.setPadding(new Insets(20));
        dialogContent.setStyle("-fx-background-color: white;");

        // Dialog başlığı
        Label title = new Label("Yeni Hasta Ekle");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 20));

        // Form alanları
        MFXTextField tcNoField = new MFXTextField();
        tcNoField.setPromptText("TC No");
        tcNoField.setPrefWidth(200);
        tcNoField.setStyle("-fx-font-size: 14px;");

        MFXTextField nameField = new MFXTextField();
        nameField.setPromptText("Ad");
        nameField.setPrefWidth(200);
        nameField.setStyle("-fx-font-size: 14px;");

        MFXTextField surnameField = new MFXTextField();
        surnameField.setPromptText("Soyad");
        surnameField.setPrefWidth(200);
        surnameField.setStyle("-fx-font-size: 14px;");

        MFXTextField phoneField = new MFXTextField();
        phoneField.setPromptText("Telefon");
        phoneField.setPrefWidth(200);
        phoneField.setStyle("-fx-font-size: 14px;");

        MFXTextField addressField = new MFXTextField();
        addressField.setPromptText("Adres");
        addressField.setPrefWidth(300);
        addressField.setStyle("-fx-font-size: 14px;");

        MFXTextField birthDateField = new MFXTextField();
        birthDateField.setPromptText("Doğum Tarihi (GG.AA.YYYY)");
        birthDateField.setPrefWidth(300);
        birthDateField.setStyle("-fx-font-size: 14px;");

        // Butonlar
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);

        MFXButton cancelButton = new MFXButton("İptal");
        cancelButton.setStyle(
            "-fx-background-color: #9E9E9E;" +
            "-fx-text-fill: white;" +
            "-fx-font-family: 'Roboto';" +
            "-fx-font-size: 14px;"
        );

        MFXButton saveButton = new MFXButton("Kaydet");
        saveButton.setStyle(
            "-fx-background-color: #2196F3;" +
            "-fx-text-fill: white;" +
            "-fx-font-family: 'Roboto';" +
            "-fx-font-size: 14px;"
        );

        buttonBox.getChildren().addAll(cancelButton, saveButton);

        // Layout
        dialogContent.getChildren().addAll(
            title,
            tcNoField,
            nameField,
            surnameField,
            phoneField,
            addressField,
            birthDateField,
            buttonBox
        );

        // Buton işlevleri
        cancelButton.setOnAction(e -> dialog.close());

        saveButton.setOnAction(e -> {
            if (tcNoField.getText().isEmpty() || 
                nameField.getText().isEmpty() || 
                surnameField.getText().isEmpty() || 
                phoneField.getText().isEmpty() || 
                addressField.getText().isEmpty() || 
                birthDateField.getText().isEmpty()) {
                showAlert("Hata", "Lütfen tüm alanları doldurun!");
                return;
            }

            // TC No kontrolü
            if (tcNoField.getText().length() != 11 || !tcNoField.getText().matches("\\d+")) {
                showAlert("Hata", "TC No 11 haneli sayısal bir değer olmalıdır!");
                return;
            }

            // Telefon kontrolü
            if (!phoneField.getText().matches("\\d{10}")) {
                showAlert("Hata", "Telefon numarası 10 haneli sayısal bir değer olmalıdır! (Başında 0 olmadan)");
                return;
            }

            // Doğum tarihi kontrolü
            if (!birthDateField.getText().matches("\\d{2}\\.\\d{2}\\.\\d{4}")) {
                showAlert("Hata", "Doğum tarihi GG.AA.YYYY formatında olmalıdır!");
                return;
            }

            Patient newPatient = new Patient(
                tcNoField.getText(),
                nameField.getText(),
                surnameField.getText(),
                phoneField.getText(),
                addressField.getText(),
                birthDateField.getText()
            );

            patients.add(newPatient);

            // Değişiklikleri kaydet
            FileUtils.savePatients(new ArrayList<>(patients));

            dialog.close();

            // Başarı mesajı
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Başarılı");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Hasta başarıyla eklendi!");
            successAlert.showAndWait();
        });

        // Gölge efekti
        VBox wrapper = new VBox(dialogContent);
        wrapper.setStyle("-fx-background-color: white;");
        wrapper.setEffect(MFXDepthManager.shadowOf(DepthLevel.LEVEL4));

        Scene scene = new Scene(wrapper);
        dialog.setScene(scene);
        dialog.show();
    }

    private static void showEditPatientDialog(Patient patient) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initStyle(StageStyle.UNDECORATED);

        VBox dialogContent = new VBox(20);
        dialogContent.setPadding(new Insets(20));
        dialogContent.setStyle("-fx-background-color: white;");

        // Dialog başlığı
        Label title = new Label("Hasta Düzenle");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 20));

        // Form alanları
        MFXTextField tcNoField = new MFXTextField(patient.getTcNo());
        tcNoField.setPromptText("TC No");
        tcNoField.setPrefWidth(200);
        tcNoField.setStyle("-fx-font-size: 14px;");

        MFXTextField nameField = new MFXTextField(patient.getName());
        nameField.setPromptText("Ad");
        nameField.setPrefWidth(200);
        nameField.setStyle("-fx-font-size: 14px;");

        MFXTextField surnameField = new MFXTextField(patient.getSurname());
        surnameField.setPromptText("Soyad");
        surnameField.setPrefWidth(200);
        surnameField.setStyle("-fx-font-size: 14px;");

        MFXTextField phoneField = new MFXTextField(patient.getPhone());
        phoneField.setPromptText("Telefon");
        phoneField.setPrefWidth(200);
        phoneField.setStyle("-fx-font-size: 14px;");

        MFXTextField addressField = new MFXTextField(patient.getAddress());
        addressField.setPromptText("Adres");
        addressField.setPrefWidth(300);
        addressField.setStyle("-fx-font-size: 14px;");

        MFXTextField birthDateField = new MFXTextField(patient.getBirthDate());
        birthDateField.setPromptText("Doğum Tarihi (GG.AA.YYYY)");
        birthDateField.setPrefWidth(300);
        birthDateField.setStyle("-fx-font-size: 14px;");

        // Butonlar
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);

        MFXButton cancelButton = new MFXButton("İptal");
        cancelButton.setStyle(
            "-fx-background-color: #9E9E9E;" +
            "-fx-text-fill: white;" +
            "-fx-font-family: 'Roboto';" +
            "-fx-font-size: 14px;"
        );

        MFXButton saveButton = new MFXButton("Kaydet");
        saveButton.setStyle(
            "-fx-background-color: #2196F3;" +
            "-fx-text-fill: white;" +
            "-fx-font-family: 'Roboto';" +
            "-fx-font-size: 14px;"
        );

        buttonBox.getChildren().addAll(cancelButton, saveButton);

        // Layout
        dialogContent.getChildren().addAll(
            title,
            tcNoField,
            nameField,
            surnameField,
            phoneField,
            addressField,
            birthDateField,
            buttonBox
        );

        // Buton işlevleri
        cancelButton.setOnAction(e -> dialog.close());

        saveButton.setOnAction(e -> {
            if (tcNoField.getText().isEmpty() || 
                nameField.getText().isEmpty() || 
                surnameField.getText().isEmpty() || 
                phoneField.getText().isEmpty() || 
                addressField.getText().isEmpty() || 
                birthDateField.getText().isEmpty()) {
                showAlert("Hata", "Lütfen tüm alanları doldurun!");
                return;
            }

            // TC No kontrolü
            if (tcNoField.getText().length() != 11 || !tcNoField.getText().matches("\\d+")) {
                showAlert("Hata", "TC No 11 haneli sayısal bir değer olmalıdır!");
                return;
            }

            // Telefon kontrolü
            if (!phoneField.getText().matches("\\d{10}")) {
                showAlert("Hata", "Telefon numarası 10 haneli sayısal bir değer olmalıdır! (Başında 0 olmadan)");
                return;
            }

            // Doğum tarihi kontrolü
            if (!birthDateField.getText().matches("\\d{2}\\.\\d{2}\\.\\d{4}")) {
                showAlert("Hata", "Doğum tarihi GG.AA.YYYY formatında olmalıdır!");
                return;
            }

            patient.setTcNo(tcNoField.getText());
            patient.setName(nameField.getText());
            patient.setSurname(surnameField.getText());
            patient.setPhone(phoneField.getText());
            patient.setAddress(addressField.getText());
            patient.setBirthDate(birthDateField.getText());

            int index = patients.indexOf(patient);
            patients.set(index, patient);
            tableView.refresh();

            // Değişiklikleri kaydet
            FileUtils.savePatients(new ArrayList<>(patients));

            dialog.close();

            // Başarı mesajı
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Başarılı");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Hasta bilgileri başarıyla güncellendi!");
            successAlert.showAndWait();
        });

        // Gölge efekti
        VBox wrapper = new VBox(dialogContent);
        wrapper.setStyle("-fx-background-color: white;");
        wrapper.setEffect(MFXDepthManager.shadowOf(DepthLevel.LEVEL4));

        Scene scene = new Scene(wrapper);
        dialog.setScene(scene);
        dialog.show();
    }

    private static void deletePatient(Patient patient) {
        Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
        confirmDialog.setTitle("Silme Onayı");
        confirmDialog.setHeaderText(null);
        confirmDialog.setContentText("Bu hastayı silmek istediğinize emin misiniz?");

        Optional<ButtonType> result = confirmDialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            patients.remove(patient);
            // Değişiklikleri kaydet
            FileUtils.savePatients(new ArrayList<>(patients));
        }
    }

    private static void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
