package com.curetech;

import io.github.palexdev.materialfx.controls.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ReportManager {
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public static void showStockReport() {
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Stok Raporu");

        VBox content = new VBox(20);
        content.setPadding(new Insets(20));

        // Başlık
        Label title = new Label("Stok Durumu Raporu");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 24));
        title.setTextFill(Color.web("#1976D2"));

        // Stok özeti
        GridPane summary = new GridPane();
        summary.setHgap(20);
        summary.setVgap(10);
        summary.addRow(0, createSummaryLabel("Toplam İlaç:"), createValueLabel("1,234"));
        summary.addRow(1, createSummaryLabel("Kritik Stok:"), createValueLabel("45"));
        summary.addRow(2, createSummaryLabel("Stok Değeri:"), createValueLabel("567,890 ₺"));

        // Stok grafiği
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> stockChart = new BarChart<>(xAxis, yAxis);
        stockChart.setTitle("Stok Seviyesi");
        
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Mevcut Stok");
        series.getData().add(new XYChart.Data<>("Antibiyotik", 150));
        series.getData().add(new XYChart.Data<>("Ağrı Kesici", 200));
        series.getData().add(new XYChart.Data<>("Vitamin", 300));
        series.getData().add(new XYChart.Data<>("Kalp İlacı", 100));
        stockChart.getData().add(series);

        // Kritik stok tablosu
        TableView<Map<String, String>> criticalTable = new TableView<>();
        criticalTable.setPrefHeight(200);

        TableColumn<Map<String, String>, String> nameCol = new TableColumn<>("İlaç Adı");
        nameCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("name")));

        TableColumn<Map<String, String>, String> stockCol = new TableColumn<>("Stok");
        stockCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("stock")));

        TableColumn<Map<String, String>, String> minStockCol = new TableColumn<>("Min. Stok");
        minStockCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("minStock")));

        criticalTable.getColumns().addAll(nameCol, stockCol, minStockCol);

        ObservableList<Map<String, String>> criticalData = FXCollections.observableArrayList();
        criticalData.add(createTableRow("Aspirin", "5", "20"));
        criticalData.add(createTableRow("Parol", "8", "25"));
        criticalData.add(createTableRow("Augmentin", "3", "15"));
        criticalTable.setItems(criticalData);

        // Yazdır butonu
        MFXButton printButton = new MFXButton("Raporu Yazdır");
        printButton.setStyle(
            "-fx-background-color: #1976D2;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );

        content.getChildren().addAll(title, summary, stockChart, new Label("Kritik Stok Listesi"), criticalTable, printButton);

        Scene scene = new Scene(content, 800, 900);
        stage.setScene(scene);
        stage.show();
    }

    public static void showSalesReport() {
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Satış Raporu");

        VBox content = new VBox(20);
        content.setPadding(new Insets(20));

        // Başlık
        Label title = new Label("Satış Raporu");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 24));
        title.setTextFill(Color.web("#1976D2"));

        // Tarih seçici
        HBox dateBox = new HBox(10);
        dateBox.setAlignment(Pos.CENTER_LEFT);
        DatePicker startDate = new DatePicker(LocalDate.now().minusMonths(1));
        DatePicker endDate = new DatePicker(LocalDate.now());
        MFXButton updateButton = new MFXButton("Güncelle");
        updateButton.setStyle("-fx-background-color: #1976D2; -fx-text-fill: white;");
        dateBox.getChildren().addAll(
            new Label("Başlangıç:"), startDate,
            new Label("Bitiş:"), endDate,
            updateButton
        );

        // Satış özeti
        GridPane summary = new GridPane();
        summary.setHgap(20);
        summary.setVgap(10);
        summary.addRow(0, createSummaryLabel("Toplam Satış:"), createValueLabel("45,678 ₺"));
        summary.addRow(1, createSummaryLabel("Toplam İşlem:"), createValueLabel("234"));
        summary.addRow(2, createSummaryLabel("Ortalama İşlem:"), createValueLabel("195 ₺"));

        // Satış grafiği
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        LineChart<String, Number> salesChart = new LineChart<>(xAxis, yAxis);
        salesChart.setTitle("Günlük Satış Grafiği");
        
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Satış");
        series.getData().add(new XYChart.Data<>("1 Nis", 1500));
        series.getData().add(new XYChart.Data<>("2 Nis", 2300));
        series.getData().add(new XYChart.Data<>("3 Nis", 1800));
        series.getData().add(new XYChart.Data<>("4 Nis", 2100));
        salesChart.getData().add(series);

        // En çok satan ürünler tablosu
        TableView<Map<String, String>> topSalesTable = new TableView<>();
        topSalesTable.setPrefHeight(200);

        TableColumn<Map<String, String>, String> nameCol = new TableColumn<>("İlaç Adı");
        nameCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("name")));

        TableColumn<Map<String, String>, String> quantityCol = new TableColumn<>("Satış Adedi");
        quantityCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("quantity")));

        TableColumn<Map<String, String>, String> revenueCol = new TableColumn<>("Gelir");
        revenueCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("revenue")));

        topSalesTable.getColumns().addAll(nameCol, quantityCol, revenueCol);

        ObservableList<Map<String, String>> salesData = FXCollections.observableArrayList();
        salesData.add(createTableRow("Aspirin", "150", "3,000 ₺"));
        salesData.add(createTableRow("Parol", "120", "2,400 ₺"));
        salesData.add(createTableRow("Augmentin", "90", "4,500 ₺"));
        topSalesTable.setItems(salesData);

        // Yazdır butonu
        MFXButton printButton = new MFXButton("Raporu Yazdır");
        printButton.setStyle(
            "-fx-background-color: #1976D2;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );

        content.getChildren().addAll(title, dateBox, summary, salesChart, new Label("En Çok Satan Ürünler"), topSalesTable, printButton);

        Scene scene = new Scene(content, 800, 900);
        stage.setScene(scene);
        stage.show();
    }

    public static void showPatientReport() {
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Hasta Raporu");

        VBox content = new VBox(20);
        content.setPadding(new Insets(20));

        // Başlık
        Label title = new Label("Hasta İstatistikleri Raporu");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 24));
        title.setTextFill(Color.web("#1976D2"));

        // Hasta özeti
        GridPane summary = new GridPane();
        summary.setHgap(20);
        summary.setVgap(10);
        summary.addRow(0, createSummaryLabel("Toplam Hasta:"), createValueLabel("567"));
        summary.addRow(1, createSummaryLabel("Aylık Yeni Hasta:"), createValueLabel("45"));
        summary.addRow(2, createSummaryLabel("Aktif Reçete:"), createValueLabel("123"));

        // Yaş dağılımı grafiği
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> ageChart = new BarChart<>(xAxis, yAxis);
        ageChart.setTitle("Yaş Dağılımı");
        
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Hasta Sayısı");
        series.getData().add(new XYChart.Data<>("0-18", 50));
        series.getData().add(new XYChart.Data<>("19-30", 120));
        series.getData().add(new XYChart.Data<>("31-50", 200));
        series.getData().add(new XYChart.Data<>("51-70", 150));
        series.getData().add(new XYChart.Data<>("71+", 47));
        ageChart.getData().add(series);

        // En sık reçete edilen ilaçlar tablosu
        TableView<Map<String, String>> prescriptionTable = new TableView<>();
        prescriptionTable.setPrefHeight(200);

        TableColumn<Map<String, String>, String> nameCol = new TableColumn<>("İlaç Adı");
        nameCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("name")));

        TableColumn<Map<String, String>, String> countCol = new TableColumn<>("Reçete Sayısı");
        countCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("count")));

        TableColumn<Map<String, String>, String> percentCol = new TableColumn<>("Yüzde");
        percentCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("percent")));

        prescriptionTable.getColumns().addAll(nameCol, countCol, percentCol);

        ObservableList<Map<String, String>> prescriptionData = FXCollections.observableArrayList();
        prescriptionData.add(createTableRow("Aspirin", "89", "%15"));
        prescriptionData.add(createTableRow("Parol", "76", "%13"));
        prescriptionData.add(createTableRow("Augmentin", "65", "%11"));
        prescriptionTable.setItems(prescriptionData);

        // Yazdır butonu
        MFXButton printButton = new MFXButton("Raporu Yazdır");
        printButton.setStyle(
            "-fx-background-color: #1976D2;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );

        content.getChildren().addAll(title, summary, ageChart, new Label("En Sık Reçete Edilen İlaçlar"), prescriptionTable, printButton);

        Scene scene = new Scene(content, 800, 900);
        stage.setScene(scene);
        stage.show();
    }

    private static Label createSummaryLabel(String text) {
        Label label = new Label(text);
        label.setFont(Font.font("Roboto", FontWeight.BOLD, 14));
        return label;
    }

    private static Label createValueLabel(String text) {
        Label label = new Label(text);
        label.setFont(Font.font("Roboto", 14));
        return label;
    }

    private static Map<String, String> createTableRow(String... values) {
        Map<String, String> row = new HashMap<>();
        row.put("name", values[0]);
        row.put("stock", values[1]);
        row.put("minStock", values.length > 2 ? values[2] : "");
        row.put("quantity", values.length > 2 ? values[1] : "");
        row.put("revenue", values.length > 2 ? values[2] : "");
        row.put("count", values.length > 2 ? values[1] : "");
        row.put("percent", values.length > 2 ? values[2] : "");
        return row;
    }
}
