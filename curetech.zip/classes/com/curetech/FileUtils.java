package com.curetech;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.*;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class FileUtils {
    private static final String DATA_DIR = "data";
    private static final String USERS_FILE = DATA_DIR + "/users.json";
    private static final String MEDICATIONS_FILE = DATA_DIR + "/medications.json";
    private static final String PATIENTS_FILE = DATA_DIR + "/patients.json";
    private static final String PRESCRIPTIONS_FILE = DATA_DIR + "/prescriptions.json";
    private static final String SALES_FILE = DATA_DIR + "/sales.json";
    
    private static final Gson gson = new GsonBuilder()
        .registerTypeAdapter(LocalDate.class, new TypeAdapter<LocalDate>() {
            @Override
            public void write(JsonWriter out, LocalDate value) throws IOException {
                out.value(value.toString());
            }

            @Override
            public LocalDate read(JsonReader in) throws IOException {
                return LocalDate.parse(in.nextString());
            }
        })
        .registerTypeAdapter(LocalDateTime.class, new TypeAdapter<LocalDateTime>() {
            @Override
            public void write(JsonWriter out, LocalDateTime value) throws IOException {
                out.value(value.toString());
            }

            @Override
            public LocalDateTime read(JsonReader in) throws IOException {
                return LocalDateTime.parse(in.nextString());
            }
        })
        .setPrettyPrinting()
        .create();

    static {
        createDataDirectory();

        // Varsayılan kullanıcıları oluştur
        if (!new File(USERS_FILE).exists()) {
            List<User> defaultUsers = new ArrayList<>();
            
            // Admin kullanıcısı
            User admin = new User("admin", "admin", "Admin", "User");
            admin.setEmail("admin@curetech.com");
            admin.setRole("admin");
            defaultUsers.add(admin);
            
            // Test kullanıcısı
            User user = new User("user", "user", "Test", "User");
            user.setEmail("user@curetech.com");
            defaultUsers.add(user);
            
            saveUsers(defaultUsers);
        }
    }

    public static void saveUsers(List<User> users) {
        saveToFile(USERS_FILE, users);
    }

    public static List<User> loadUsers() {
        Type type = new TypeToken<List<User>>(){}.getType();
        List<User> users = loadFromFile(USERS_FILE, type);
        return users != null ? users : new ArrayList<>();
    }

    public static User getUser(String username) {
        return loadUsers().stream()
                .filter(u -> u.getUsername().equals(username))
                .findFirst()
                .orElse(null);
    }

    public static User validateUser(String username, String password) {
        try {
            // Kullanıcı listesini oku
            List<User> users = loadUsers();
            
            // Kullanıcı adı ve şifreyi kontrol et
            for (User user : users) {
                if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                    return user;
                }
            }
            
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void savePatients(List<Patient> patients) {
        saveToFile(PATIENTS_FILE, patients);
    }

    public static List<Patient> loadPatients() {
        Type type = new TypeToken<List<Patient>>(){}.getType();
        List<Patient> patients = loadFromFile(PATIENTS_FILE, type);
        return patients != null ? patients : new ArrayList<>();
    }

    public static void saveMedications(List<Medication> medications) {
        saveToFile(MEDICATIONS_FILE, medications);
    }

    public static List<Medication> loadMedications() {
        Type type = new TypeToken<List<Medication>>(){}.getType();
        List<Medication> medications = loadFromFile(MEDICATIONS_FILE, type);
        return medications != null ? medications : new ArrayList<>();
    }

    public static void savePrescriptions(List<Prescription> prescriptions) {
        System.out.println("Reçeteler kaydediliyor... Sayı: " + prescriptions.size());
        saveToFile(PRESCRIPTIONS_FILE, prescriptions);
        System.out.println("Reçeteler kaydedildi");
    }

    public static List<Prescription> loadPrescriptions() {
        System.out.println("Reçeteler yükleniyor...");
        Type type = new TypeToken<List<Prescription>>(){}.getType();
        List<Prescription> prescriptions = loadFromFile(PRESCRIPTIONS_FILE, type);
        System.out.println("Reçeteler yüklendi. Sayı: " + (prescriptions != null ? prescriptions.size() : 0));
        return prescriptions != null ? prescriptions : new ArrayList<>();
    }

    public static void saveSales(List<Sale> sales) {
        System.out.println("Satışlar kaydediliyor... Sayı: " + sales.size());
        saveToFile(SALES_FILE, sales);
        System.out.println("Satışlar kaydedildi");
    }

    public static List<Sale> loadSales() {
        System.out.println("Satışlar yükleniyor...");
        Type type = new TypeToken<List<Sale>>(){}.getType();
        List<Sale> sales = loadFromFile(SALES_FILE, type);
        System.out.println("Satışlar yüklendi. Sayı: " + (sales != null ? sales.size() : 0));
        return sales != null ? sales : new ArrayList<>();
    }

    public static void createDataDirectory() {
        File dataDir = new File(DATA_DIR);
        if (!dataDir.exists()) {
            if (dataDir.mkdirs()) {
                System.out.println("Veri dizini oluşturuldu: " + DATA_DIR);
            } else {
                System.err.println("Veri dizini oluşturulamadı: " + DATA_DIR);
            }
        }
    }

    private static <T> void saveToFile(String filePath, T data) {
        try {
            // Önce dosya ve dizin varlığını kontrol et
            File file = new File(filePath);
            if (!file.exists()) {
                file.getParentFile().mkdirs();
                file.createNewFile();
            }
            
            // Dosyaya yaz
            try (Writer writer = new FileWriter(file)) {
                gson.toJson(data, writer);
            }
        } catch (IOException e) {
            System.err.println("Dosya kaydedilirken hata oluştu: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static <T> T loadFromFile(String filePath, Type type) {
        File file = new File(filePath);
        if (!file.exists()) {
            System.out.println("Dosya bulunamadı: " + filePath);
            return null;
        }
        
        try (Reader reader = new FileReader(file)) {
            return gson.fromJson(reader, type);
        } catch (IOException e) {
            System.err.println("Dosya okunurken hata oluştu: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}
