package com.curetech;

public class SaleItem {
    private String medicationId;
    private String medicationName;
    private int quantity;
    private double unitPrice;

    public SaleItem(String medicationId, String medicationName, int quantity, double unitPrice) {
        this.medicationId = medicationId;
        this.medicationName = medicationName;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
    }

    // Getters
    public String getMedicationId() { return medicationId; }
    public String getMedicationName() { return medicationName; }
    public int getQuantity() { return quantity; }
    public double getUnitPrice() { return unitPrice; }
    public double getTotal() { return quantity * unitPrice; }

    // Setters
    public void setMedicationId(String medicationId) { this.medicationId = medicationId; }
    public void setMedicationName(String medicationName) { this.medicationName = medicationName; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }
}
