package com.curetech;

import io.github.palexdev.materialfx.controls.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import java.util.List;
import java.util.Optional;
import java.util.function.UnaryOperator;
import javafx.util.converter.IntegerStringConverter;
import javafx.util.converter.DoubleStringConverter;

public class MedicationManagement {
    private static TableView<Medication> medicationTable;
    private static ObservableList<Medication> medications;

    public static ObservableList<Medication> getMedications() {
        if (medications == null) {
            medications = FXCollections.observableArrayList(FileUtils.loadMedications());
        }
        return medications;
    }

    public static void saveMedications(ObservableList<Medication> meds) {
        FileUtils.saveMedications(new java.util.ArrayList<>(meds));
        medications = meds;
    }

    public static VBox getContent() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));

        VBox headerBox = createHeaderBox();

        // Orta kısım - İlaç tablosu
        VBox tableBox = createTableBox();

        // Alt kısım - Butonlar
        HBox buttonBox = createButtonBox();

        content.getChildren().addAll(headerBox, tableBox, buttonBox);
        return content;
    }

    private static VBox createHeaderBox() {
        VBox headerBox = new VBox(15);
        headerBox.setStyle("-fx-background-color: white; -fx-border-color: #E0E0E0; -fx-border-width: 0 0 1 0;");
        headerBox.setPadding(new Insets(0, 0, 15, 0));

        // Başlık
        Label title = new Label("İlaç Yönetimi");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 24));
        title.setTextFill(Color.web("#1A1A1A"));

        // Buton ve Arama Satırı
        HBox actionBox = new HBox(15);
        actionBox.setAlignment(Pos.CENTER_LEFT);

        // Arama Alanı
        TextField searchField = new TextField();
        searchField.setPromptText("Barkod veya isim ile arama yapın");
        searchField.setPrefWidth(460);
        searchField.setStyle("-fx-font-size: 14px;");

        // Yeni İlaç Butonu
        MFXButton addButton = new MFXButton("+ Yeni İlaç");
        addButton.setStyle(
            "-fx-background-color: #4CAF50;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );
        addButton.setOnAction(e -> showAddMedicationDialog());

        // Arama işlevselliği
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue == null || newValue.isEmpty()) {
                medicationTable.setItems(medications);
            } else {
                ObservableList<Medication> filteredList = FXCollections.observableArrayList();
                for (Medication medication : medications) {
                    if (medication.getName().toLowerCase().contains(newValue.toLowerCase()) ||
                        medication.getManufacturer().toLowerCase().contains(newValue.toLowerCase()) ||
                        medication.getType().toLowerCase().contains(newValue.toLowerCase())) {
                        filteredList.add(medication);
                    }
                }
                medicationTable.setItems(filteredList);
            }
        });

        actionBox.getChildren().addAll(searchField, addButton);
        headerBox.getChildren().addAll(title, actionBox);
        return headerBox;
    }

    private static VBox createTableBox() {
        VBox box = new VBox(10);

        // İlaç tablosu
        medicationTable = new TableView<>();
        medications = getMedications();

        TableColumn<Medication, String> barkodCol = new TableColumn<>("Barkod");
        barkodCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getBarkod()));
        barkodCol.setPrefWidth(120);

        TableColumn<Medication, String> nameCol = new TableColumn<>("İlaç Adı");
        nameCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));
        nameCol.setPrefWidth(200);

        TableColumn<Medication, String> descriptionCol = new TableColumn<>("Açıklama");
        descriptionCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getDescription()));
        descriptionCol.setPrefWidth(200);

        TableColumn<Medication, String> typeCol = new TableColumn<>("Tip");
        typeCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getType()));
        typeCol.setPrefWidth(100);

        TableColumn<Medication, String> manufacturerCol = new TableColumn<>("Üretici");
        manufacturerCol.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getManufacturer()));
        manufacturerCol.setPrefWidth(150);

        TableColumn<Medication, String> stockCol = new TableColumn<>("Stok");
        stockCol.setCellValueFactory(data -> {
            int stock = data.getValue().getStock();
            String stockText = String.valueOf(stock);
            if (stock <= data.getValue().getMinStock()) {
                stockText += " (Düşük Stok!)";
            }
            return new javafx.beans.property.SimpleStringProperty(stockText);
        });
        stockCol.setPrefWidth(80);

        TableColumn<Medication, Number> priceCol = new TableColumn<>("Fiyat");
        priceCol.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getPrice()));
        priceCol.setPrefWidth(80);

        medicationTable.getColumns().addAll(barkodCol, nameCol, descriptionCol, typeCol, manufacturerCol, stockCol, priceCol);
        medicationTable.setItems(medications);
        medicationTable.setPrefHeight(400);

        box.getChildren().add(medicationTable);
        return box;
    }

    private static HBox createButtonBox() {
        HBox box = new HBox(10);
        box.setAlignment(Pos.CENTER_RIGHT);

        MFXButton editButton = new MFXButton("Düzenle");
        editButton.setStyle(
            "-fx-background-color: #1976D2;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );

        MFXButton deleteButton = new MFXButton("Sil");
        deleteButton.setStyle(
            "-fx-background-color: #F44336;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );

        editButton.setOnAction(e -> {
            Medication selected = medicationTable.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showEditMedicationDialog(selected);
            }
        });
        deleteButton.setOnAction(e -> {
            Medication selected = medicationTable.getSelectionModel().getSelectedItem();
            if (selected != null) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("İlaç Sil");
                alert.setHeaderText(null);
                alert.setContentText(selected.getName() + " ilacını silmek istediğinize emin misiniz?");

                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    medications.remove(selected);
                    saveMedications(medications);
                }
            }
        });

        box.getChildren().addAll(editButton, deleteButton);
        return box;
    }

    private static void showAddMedicationDialog() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Yeni İlaç Ekle");

        // Form alanları
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        MFXTextField barkodField = new MFXTextField();
        barkodField.setPromptText("Barkod");
        barkodField.setPrefWidth(200);
        barkodField.setStyle("-fx-font-size: 14px;");

        MFXTextField nameField = new MFXTextField();
        nameField.setPromptText("İlaç Adı");
        nameField.setPrefWidth(200);
        nameField.setStyle("-fx-font-size: 14px;");

        MFXTextField descriptionField = new MFXTextField();
        descriptionField.setPromptText("Açıklama");
        descriptionField.setPrefWidth(200);
        descriptionField.setStyle("-fx-font-size: 14px;");

        MFXTextField typeField = new MFXTextField();
        typeField.setPromptText("Tür");
        typeField.setPrefWidth(200);
        typeField.setStyle("-fx-font-size: 14px;");

        MFXTextField manufacturerField = new MFXTextField();
        manufacturerField.setPromptText("Üretici");
        manufacturerField.setPrefWidth(200);
        manufacturerField.setStyle("-fx-font-size: 14px;");

        MFXTextField priceField = new MFXTextField();
        priceField.setPromptText("Fiyat");
        priceField.setPrefWidth(200);
        priceField.setStyle("-fx-font-size: 14px;");

        MFXTextField stockField = new MFXTextField();
        stockField.setPromptText("Stok");
        stockField.setPrefWidth(200);
        stockField.setStyle("-fx-font-size: 14px;");

        MFXTextField minStockField = new MFXTextField();
        minStockField.setPromptText("Minimum Stok");
        minStockField.setPrefWidth(200);
        minStockField.setStyle("-fx-font-size: 14px;");

        grid.add(barkodField, 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(descriptionField, 0, 1);
        grid.add(typeField, 1, 1);
        grid.add(manufacturerField, 0, 2);
        grid.add(priceField, 1, 2);
        grid.add(stockField, 0, 3);
        grid.add(minStockField, 1, 3);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        // Validation
        Node okButton = dialog.getDialogPane().lookupButton(ButtonType.OK);
        okButton.setDisable(true);

        // Enable OK button when required fields are filled
        nameField.textProperty().addListener((observable, oldValue, newValue) -> {
            okButton.setDisable(newValue.trim().isEmpty());
        });

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                try {
                    Medication newMedication = new Medication(
                        barkodField.getText(),
                        nameField.getText(),
                        descriptionField.getText(),
                        typeField.getText(),
                        manufacturerField.getText(),
                        Integer.parseInt(stockField.getText()),
                        Double.parseDouble(priceField.getText()),
                        Integer.parseInt(minStockField.getText())
                    );

                    medications.add(newMedication);
                    saveMedications(medications);
                    dialog.close();
                } catch (NumberFormatException e) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Hata");
                    alert.setHeaderText("Geçersiz değer");
                    alert.setContentText("Lütfen sayısal alanları doğru formatta girin.");
                    alert.showAndWait();
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    private static void showEditMedicationDialog(Medication medication) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("İlaç Düzenle");

        // Form alanları
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        MFXTextField barkodField = new MFXTextField(medication.getBarkod());
        barkodField.setPromptText("Barkod");
        barkodField.setPrefWidth(200);
        barkodField.setStyle("-fx-font-size: 14px;");

        MFXTextField nameField = new MFXTextField(medication.getName());
        nameField.setPromptText("İlaç Adı");
        nameField.setPrefWidth(200);
        nameField.setStyle("-fx-font-size: 14px;");

        MFXTextField descriptionField = new MFXTextField(medication.getDescription());
        descriptionField.setPromptText("Açıklama");
        descriptionField.setPrefWidth(200);
        descriptionField.setStyle("-fx-font-size: 14px;");

        MFXTextField typeField = new MFXTextField(medication.getType());
        typeField.setPromptText("Tür");
        typeField.setPrefWidth(200);
        typeField.setStyle("-fx-font-size: 14px;");

        MFXTextField manufacturerField = new MFXTextField(medication.getManufacturer());
        manufacturerField.setPromptText("Üretici");
        manufacturerField.setPrefWidth(200);
        manufacturerField.setStyle("-fx-font-size: 14px;");

        MFXTextField priceField = new MFXTextField(String.valueOf(medication.getPrice()));
        priceField.setPromptText("Fiyat");
        priceField.setPrefWidth(200);
        priceField.setStyle("-fx-font-size: 14px;");

        MFXTextField stockField = new MFXTextField(String.valueOf(medication.getStock()));
        stockField.setPromptText("Stok");
        stockField.setPrefWidth(200);
        stockField.setStyle("-fx-font-size: 14px;");

        MFXTextField minStockField = new MFXTextField(String.valueOf(medication.getMinStock()));
        minStockField.setPromptText("Minimum Stok");
        minStockField.setPrefWidth(200);
        minStockField.setStyle("-fx-font-size: 14px;");

        grid.add(barkodField, 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(descriptionField, 0, 1);
        grid.add(typeField, 1, 1);
        grid.add(manufacturerField, 0, 2);
        grid.add(priceField, 1, 2);
        grid.add(stockField, 0, 3);
        grid.add(minStockField, 1, 3);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                try {
                    medication.setBarkod(barkodField.getText());
                    medication.setName(nameField.getText());
                    medication.setDescription(descriptionField.getText());
                    medication.setType(typeField.getText());
                    medication.setManufacturer(manufacturerField.getText());
                    medication.setPrice(Double.parseDouble(priceField.getText()));
                    medication.setStock(Integer.parseInt(stockField.getText()));
                    medication.setMinStock(Integer.parseInt(minStockField.getText()));

                    medicationTable.refresh();
                    saveMedications(medications);
                    dialog.close();
                } catch (NumberFormatException e) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Hata");
                    alert.setHeaderText("Geçersiz değer");
                    alert.setContentText("Lütfen sayısal alanları doğru formatta girin.");
                    alert.showAndWait();
                }
            }
            return null;
        });

        dialog.showAndWait();
    }
}
