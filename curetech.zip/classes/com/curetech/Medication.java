package com.curetech;

import java.util.Objects;

public class Medication {
    private String barkod;
    private String name;
    private String description;
    private String type;
    private String manufacturer;
    private int stock;
    private double price;
    private int minStock;

    public Medication(String barkod, String name, String description, String type, String manufacturer, int stock, double price, int minStock) {
        this.barkod = barkod;
        this.name = name;
        this.description = description;
        this.type = type;
        this.manufacturer = manufacturer;
        this.stock = stock;
        this.price = price;
        this.minStock = minStock;
    }

    // Getters
    public String getBarkod() { return barkod; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getType() { return type; }
    public String getManufacturer() { return manufacturer; }
    public int getStock() { return stock; }
    public double getPrice() { return price; }
    public int getMinStock() { return minStock; }

    // Setters
    public void setBarkod(String barkod) { this.barkod = barkod; }
    public void setName(String name) { this.name = name; }
    public void setDescription(String description) { this.description = description; }
    public void setType(String type) { this.type = type; }
    public void setManufacturer(String manufacturer) { this.manufacturer = manufacturer; }
    public void setStock(int stock) { this.stock = stock; }
    public void setPrice(double price) { this.price = price; }
    public void setMinStock(int minStock) { this.minStock = minStock; }

    // Stok işlemleri
    public boolean decreaseStock(int amount) {
        if (stock >= amount) {
            stock -= amount;
            return true;
        }
        return false;
    }

    public void increaseStock(int amount) {
        stock += amount;
    }

    public boolean isLowStock() {
        return stock <= minStock;
    }

    @Override
    public String toString() {
        return name + " (" + type + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Medication that = (Medication) o;
        return Objects.equals(barkod, that.barkod);
    }

    @Override
    public int hashCode() {
        return Objects.hash(barkod);
    }
}
