package com.curetech;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Sale {
    private String id;
    private String patientTcNo;
    private LocalDateTime saleDate;
    private List<SaleItem> items;
    private double totalAmount;
    private String paymentMethod;
    private String status; // "Completed", "Cancelled", "Pending"

    public Sale(String id, String patientTcNo) {
        this.id = id;
        this.patientTcNo = patientTcNo;
        this.saleDate = LocalDateTime.now();
        this.items = new ArrayList<>();
        this.totalAmount = 0.0;
        this.status = "Pending";
    }

    // Getters
    public String getId() { return id; }
    public String getPatientTcNo() { return patientTcNo; }
    public LocalDateTime getSaleDate() { return saleDate; }
    public List<SaleItem> getItems() { return items; }
    public double getTotalAmount() { return totalAmount; }
    public String getPaymentMethod() { return paymentMethod; }
    public String getStatus() { return status; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setPatientTcNo(String patientTcNo) { this.patientTcNo = patientTcNo; }
    public void setSaleDate(LocalDateTime saleDate) { this.saleDate = saleDate; }
    public void setItems(List<SaleItem> items) { 
        this.items = items;
        calculateTotal();
    }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
    public void setStatus(String status) { this.status = status; }
    public void setTotalAmount(double amount) {
        this.totalAmount = amount;
    }

    // Helper methods
    public void addItem(SaleItem item) {
        items.add(item);
        calculateTotal();
    }

    public void removeItem(SaleItem item) {
        items.remove(item);
        calculateTotal();
    }

    private void calculateTotal() {
        this.totalAmount = items.stream()
            .mapToDouble(item -> item.getQuantity() * item.getUnitPrice())
            .sum();
    }

    public void completeSale(String paymentMethod) {
        this.paymentMethod = paymentMethod;
        this.status = "Completed";
        this.saleDate = LocalDateTime.now();
    }

    public void cancelSale() {
        this.status = "Cancelled";
    }
}
