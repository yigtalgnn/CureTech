package com.curetech;

public class Settings {
    private static Settings instance;
    private String theme = "light";
    private int criticalStockLevel = 10;
    private boolean stockNotifications = true;
    private boolean expiryNotifications = true;
    private String pharmacyName = "CureTech Eczanesi";
    private String pharmacyAddress = "";
    private String pharmacyPhone = "";
    private String pharmacyEmail = "";
    private int fontSize = 14;

    private Settings() {}

    public static Settings getInstance() {
        if (instance == null) {
            instance = new Settings();
            loadSettings();
        }
        return instance;
    }

    private static void loadSettings() {
        // TODO: JSON'dan ayarları yükle
    }

    public void saveSettings() {
        // TODO: JSON'a ayarları kaydet
    }

    // Getters and Setters
    public String getTheme() { return theme; }
    public void setTheme(String theme) { this.theme = theme; }

    public int getCriticalStockLevel() { return criticalStockLevel; }
    public void setCriticalStockLevel(int level) { this.criticalStockLevel = level; }

    public boolean isStockNotificationsEnabled() { return stockNotifications; }
    public void setStockNotifications(boolean enabled) { this.stockNotifications = enabled; }

    public boolean isExpiryNotificationsEnabled() { return expiryNotifications; }
    public void setExpiryNotifications(boolean enabled) { this.expiryNotifications = enabled; }

    public String getPharmacyName() { return pharmacyName; }
    public void setPharmacyName(String name) { this.pharmacyName = name; }

    public String getPharmacyAddress() { return pharmacyAddress; }
    public void setPharmacyAddress(String address) { this.pharmacyAddress = address; }

    public String getPharmacyPhone() { return pharmacyPhone; }
    public void setPharmacyPhone(String phone) { this.pharmacyPhone = phone; }

    public String getPharmacyEmail() { return pharmacyEmail; }
    public void setPharmacyEmail(String email) { this.pharmacyEmail = email; }

    public int getFontSize() { return fontSize; }
    public void setFontSize(int size) { this.fontSize = size; }
}
