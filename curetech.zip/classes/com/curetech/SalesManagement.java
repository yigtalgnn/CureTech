package com.curetech;

import io.github.palexdev.materialfx.controls.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.StringConverter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.UnaryOperator;
import javafx.util.converter.IntegerStringConverter;

public class SalesManagement {
    private static TableView<Map<String, String>> cartTable;
    private static ObservableList<Map<String, String>> cartItems;
    private static Label totalLabel;
    private static double total = 0.0;
    private static ObservableList<Medication> medications;
    private static MFXComboBox<String> paymentType;

    public static VBox getContent() {
        // İlaç listesini MedicationManagement'tan al
        medications = MedicationManagement.getMedications();

        VBox content = new VBox(20);
        content.setPadding(new Insets(20));

        // Başlık
        Label title = new Label("Satış İşlemleri");
        title.setFont(Font.font("Roboto", FontWeight.BOLD, 24));
        title.setTextFill(Color.web("#1976D2"));

        // Üst kısım - Ürün ekleme
        HBox addItemBox = createAddItemSection();

        // Orta kısım - Sepet
        VBox cartSection = createCartSection();

        // Alt kısım - Toplam ve ödeme
        HBox paymentBox = createPaymentSection();

        content.getChildren().addAll(title, addItemBox, cartSection, paymentBox);
        return content;
    }

    private static HBox createAddItemSection() {
        HBox box = new HBox(10);
        box.setAlignment(Pos.CENTER_LEFT);

        // İlaç seçimi
        MFXComboBox<Medication> medicationCombo = new MFXComboBox<>();
        medicationCombo.setFloatingText("");
        medicationCombo.setPromptText("İlaç Seçin");
        
        // Sadece stokta olan ilaçları göster
        ObservableList<Medication> availableMeds = FXCollections.observableArrayList(
            medications.filtered(m -> m.getStock() > 0)
        );
        medicationCombo.setItems(availableMeds);
        medicationCombo.setPrefWidth(300);

        // Miktar
        MFXTextField quantityField = new MFXTextField();
        quantityField.setFloatingText("");
        quantityField.setPromptText("Miktar");
        quantityField.setPrefWidth(100);
        quantityField.setTextLimit(3);

        // Sadece sayı girişine izin ver
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String newText = change.getControlNewText();
            if (newText.matches("[0-9]*")) {
                return change;
            }
            return null;
        };

        StringConverter<Integer> converter = new IntegerStringConverter();
        TextFormatter<Integer> textFormatter = new TextFormatter<>(converter, null, filter);
        quantityField.setTextFormatter(textFormatter);

        // Stok bilgisi
        Label stockLabel = new Label("");
        stockLabel.setTextFill(Color.web("#757575"));

        medicationCombo.setOnAction(e -> {
            Medication selected = medicationCombo.getValue();
            if (selected != null) {
                stockLabel.setText(String.format("Stok: %d", selected.getStock()));
                if (selected.isLowStock()) {
                    stockLabel.setTextFill(Color.web("#F44336"));
                } else {
                    stockLabel.setTextFill(Color.web("#757575"));
                }
            }
        });

        // Sepete ekle butonu
        MFXButton addButton = new MFXButton("Sepete Ekle");
        addButton.setStyle(
            "-fx-background-color: #1976D2;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );

        addButton.setOnAction(e -> {
            Medication medication = medicationCombo.getValue();
            String quantityStr = quantityField.getText();

            if (medication == null || quantityStr.isEmpty()) {
                showError("Lütfen ilaç ve miktar seçin!");
                return;
            }

            try {
                int quantity = Integer.parseInt(quantityStr);
                if (quantity <= 0) {
                    showError("Lütfen geçerli bir miktar girin!");
                    return;
                }

                if (quantity > medication.getStock()) {
                    showError("Stokta yeteri ürün yok!");
                    return;
                }

                // Sepete ekle
                Map<String, String> item = new HashMap<>();
                item.put("barkod", medication.getBarkod());
                item.put("name", medication.getName());
                item.put("quantity", String.valueOf(quantity));
                item.put("price", String.valueOf(medication.getPrice()));
                double itemTotal = medication.getPrice() * quantity;
                item.put("total", String.format("%.2f", itemTotal));
                item.put("medicationObj", medication.toString());

                cartItems.add(item);
                updateTotal();

                // Alanları temizle
                medicationCombo.clear();
                quantityField.clear();

            } catch (NumberFormatException ex) {
                showError("Lütfen geçerli bir miktar girin!");
            }
        });

        box.getChildren().addAll(medicationCombo, quantityField, stockLabel, addButton);
        return box;
    }

    private static VBox createCartSection() {
        VBox box = new VBox(10);

        // Sepet tablosu
        cartTable = new TableView<>();
        cartItems = FXCollections.observableArrayList();

        TableColumn<Map<String, String>, String> medicationCol = new TableColumn<>("İlaç");
        medicationCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("name")));
        medicationCol.setPrefWidth(200);

        TableColumn<Map<String, String>, String> quantityCol = new TableColumn<>("Miktar");
        quantityCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("quantity")));
        quantityCol.setPrefWidth(100);

        TableColumn<Map<String, String>, String> priceCol = new TableColumn<>("Birim Fiyat");
        priceCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("price")));
        priceCol.setPrefWidth(100);

        TableColumn<Map<String, String>, String> totalCol = new TableColumn<>("Toplam");
        totalCol.setCellValueFactory(p -> new javafx.beans.property.SimpleStringProperty(p.getValue().get("total")));
        totalCol.setPrefWidth(100);

        cartTable.getColumns().addAll(medicationCol, quantityCol, priceCol, totalCol);
        cartTable.setItems(cartItems);
        cartTable.setPrefHeight(300);

        // Seçili ürünü silme butonu
        MFXButton removeButton = new MFXButton("Seçili Ürünü Sil");
        removeButton.setStyle(
            "-fx-background-color: #F44336;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );

        removeButton.setOnAction(e -> {
            Map<String, String> selectedItem = cartTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                double itemTotal = Double.parseDouble(selectedItem.get("total"));
                total -= itemTotal;
                updateTotal();
                cartItems.remove(selectedItem);
            }
        });

        box.getChildren().addAll(cartTable, removeButton);
        return box;
    }

    private static HBox createPaymentSection() {
        HBox box = new HBox(20);
        box.setAlignment(Pos.CENTER_RIGHT);

        // Ödeme tipi
        paymentType = new MFXComboBox<>();
        paymentType.setFloatingText("");
        paymentType.setPromptText("Ödeme Tipi");
        paymentType.getItems().addAll("Nakit", "Kredi Kartı", "Sigorta");
        paymentType.setPrefWidth(200);
        paymentType.setOnAction(e -> updateTotal()); // Ödeme tipi değişince toplamı güncelle

        // Toplam
        totalLabel = new Label("Toplam: 0.00 TL");
        totalLabel.setFont(Font.font("Roboto", FontWeight.BOLD, 18));
        totalLabel.setTextFill(Color.web("#1976D2"));

        // Ödeme al butonu
        MFXButton payButton = new MFXButton("Ödeme Al");
        payButton.setStyle(
            "-fx-background-color: #4CAF50;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 14px;"
        );

        payButton.setOnAction(e -> {
            if (!cartItems.isEmpty()) {
                // Stokları güncelle
                boolean success = true;
                for (Map<String, String> item : cartItems) {
                    String medName = item.get("name");
                    int quantity = Integer.parseInt(item.get("quantity"));
                    
                    // İlacı bul ve stoktan düş
                    Optional<Medication> med = medications.stream()
                        .filter(m -> m.getName().equals(medName))
                        .findFirst();
                    
                    if (med.isPresent()) {
                        if (!med.get().decreaseStock(quantity)) {
                            success = false;
                            showError("Stok güncellenirken hata oluştu: " + medName);
                            break;
                        }
                    }
                }

                if (success) {
                    // İlaç listesini kaydet
                    MedicationManagement.saveMedications(medications);

                    // Satış kaydını oluştur
                    String paymentMethod = paymentType.getValue();
                    LocalDateTime now = LocalDateTime.now();
                    String saleId = now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
                    
                    // TODO: Satış kaydını veritabanına kaydet
                    
                    // Sepeti temizle
                    cartItems.clear();
                    total = 0.0;
                    updateTotal();

                    // Başarılı mesajı göster
                    showSuccess("Satış başarıyla tamamlandı!\nSatış No: " + saleId);
                }
            }
        });

        box.getChildren().addAll(totalLabel, paymentType, payButton);
        return box;
    }

    private static void updateTotal() {
        total = 0.0;
        for (Map<String, String> item : cartItems) {
            double price = Double.parseDouble(item.get("price"));
            int quantity = Integer.parseInt(item.get("quantity"));
            total += price * quantity;
        }
        
        // Sigorta ödemelerinde %10 indirim uygula
        if (paymentType.getValue() != null && paymentType.getValue().equals("Sigorta")) {
            double discount = total * 0.10;
            total = total - discount;
            totalLabel.setText(String.format("Toplam: %.2f TL (Sigorta İndirimi: -%.2f TL)", total, discount));
        } else {
            totalLabel.setText(String.format("Toplam: %.2f TL", total));
        }
    }

    private static void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Hata");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private static void showSuccess(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Başarılı");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
